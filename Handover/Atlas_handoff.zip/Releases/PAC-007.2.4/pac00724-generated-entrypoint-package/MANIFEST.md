# PAC-007.2.4 Generated Entrypoint Package Manifest

## Package

`atlas-pac00724-generated-entrypoint.zip`

## Contents

- `CHANGE_NOTE.md`
- `STATUS.md`
- `START_HERE.md`
- `CHANGE_PROTOCOL.md`
- `README.md`
- `atlas_generate_start_here.py`
- `atlas_validate.py`

## Purpose

Archive the generated entrypoint protocol introduced by PAC-007.2.4.

## Commands

```bash
py tools/atlas_generate_start_here.py
py tools/atlas_generate_start_here.py --check
py tools/atlas_validate.py
```
