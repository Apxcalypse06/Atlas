# PAC-007.2.4 Change Note

## Date

2026-07-02

## Change

Added generated entrypoint support for `START_HERE.md`.

## Added

- `tools/atlas_generate_start_here.py`
- `Current/PAC-007.2.4/STATUS.md`

## Updated

- `START_HERE.md`
- `GOVERNANCE/CHANGE_PROTOCOL.md`
- `tools/atlas_validate.py`
- `README/README.md`
- `MANIFEST.json`

## Reason

`START_HERE.md` is the official resume entrypoint. It must not drift from `MANIFEST.json` as PACs and patch PACs are added.

## Scope

This patch adds generation and validation for the entrypoint.

It does not implement PAC-007.3.
