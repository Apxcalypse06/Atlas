# PAC-007.2.4 - Generated Entrypoint Protocol

Status: Done

## Purpose

Make `START_HERE.md` a generated artifact instead of a manually maintained file.

## Why This Patch Exists

`START_HERE.md` is now the official resume entrypoint for future assistants.

If it is edited manually after every PAC, it can drift from `MANIFEST.json` and the current PAC status files.

PAC-007.2.4 adds generation and validation so the entrypoint stays aligned with Atlas state.

## Added

- `tools/atlas_generate_start_here.py`
- `Current/PAC-007.2.4/STATUS.md`

## Updated

- `START_HERE.md`
- `GOVERNANCE/CHANGE_PROTOCOL.md`
- `tools/atlas_validate.py`
- `README/README.md`
- `MANIFEST.json`

## Commands

Regenerate:

```bash
py tools/atlas_generate_start_here.py
```

Check without writing:

```bash
py tools/atlas_generate_start_here.py --check
```

Validate Atlas:

```bash
py tools/atlas_validate.py
```

## Enforcement

`tools/atlas_validate.py` now fails if `START_HERE.md` does not match the generator output for the current `MANIFEST.json`.

## Non-goals

- no PAC-007.3 implementation;
- no memory commit;
- no handover generation;
- no change to PAC-007.2 selection behavior.
