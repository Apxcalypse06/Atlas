# PAC-007.2.4 QA Checklist

- [x] Entrypoint generator exists.
- [x] Generator supports write mode.
- [x] Generator supports `--check`.
- [x] `START_HERE.md` declares itself generated.
- [x] Change protocol requires regeneration.
- [x] Validator imports generator.
- [x] Validator fails if generated content drifts.
- [x] `MANIFEST.json` includes PAC-007.2.4.
- [x] Release archive exists.
- [x] QA archive exists.
