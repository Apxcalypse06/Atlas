# PAC-007.2.3 QA Checklist

- [x] Backup directory documentation exists.
- [x] Backup tool exists.
- [x] Change protocol requires backups before future structural changes.
- [x] Manifest declares backup policy.
- [x] Validator checks backup policy.
- [x] Validator passes after archives are created.
- [x] Backup tool can create a ZIP snapshot.
- [x] Backup tool excludes `Backups/` to avoid recursive snapshots.
- [x] Backup tool writes `BACKUP_MANIFEST.json` inside snapshots.
- [x] Release archive exists.
- [x] QA archive exists.
