# Welcome to Atlas

This is the human entry point for resuming the Atlas project.

This file was formalized by PAC-007.2.1 as a governance/resume patch.

If you are a new assistant, read these files in this order:

1. `GOVERNANCE/CHANGE_PROTOCOL.md`
2. `BACKUPS/README.md`
3. `README/README.md`
4. `Architecture/ATLAS_ARCHITECTURE.md`
5. `Architecture/ATLAS_MEMORY_ARCHITECTURE.md`
6. `Current/PAC-007.2/STATUS.md`
7. `Current/PAC-007.2.3/STATUS.md`
8. `MANIFEST.json`
9. `Handover/Atlas_PAC_Handover_Current_Context_v2.txt`

Before editing anything structural, run:

```bash
py tools/atlas_validate.py
```

Then follow `GOVERNANCE/CHANGE_PROTOCOL.md`.

Before future structural changes, create a rollback snapshot:

```bash
py tools/atlas_backup.py <PAC_ID>
```

## Resume Here

Atlas is a cognitive continuity subsystem.

Current state:

- PAC-001 through PAC-006 are done.
- PAC-007.1 is done.
- PAC-007.2 is feature complete.
- PAC-007.2.1 is done.
- PAC-007.2.2 is done.
- PAC-007.2.3 is done.
- PAC-007.2 added knowledge selection and classification.
- PAC-007.2.1 added this resume entrypoint.
- PAC-007.2.2 added governance enforcement and validation.
- PAC-007.2.3 added backup and rollback protocol.
- PAC-007.2 does not commit memory.

The next task is:

```text
PAC-007.3 - Memory Commit
```

PAC-007.3 should read PAC-007.2 selection artifacts and commit only selected candidates into the appropriate future memory domain:

- `user/memory.json`
- `projects/<project_id>/memory.json`
- `shared/memory.json`

## Core Invariant

An artifact never modifies its source artifact.

Each stage reads the previous artifact and produces a new artifact.

## Current Pipeline

```text
Conversation
    -> Session
    -> Analysis
    -> Validation
    -> Selection / Classification
    -> Memory Commit
    -> Handover
```

## Important Boundaries

PAC-007.2:

- selects candidate information;
- classifies kept candidates as `user`, `project`, or `shared`;
- writes `sessions/selection/<session_id>.selection.json`;
- does not write memory files.

PAC-007.3:

- should commit selected candidates into memory;
- should preserve provenance;
- should ignore `keep=false` candidates;
- should not modify source session, analysis, validation, or selection artifacts.

PAC-008:

- should generate handovers later;
- is not part of PAC-007.3.

## Release Artifacts

Current implemented release:

- `Releases/PAC-007.2/pac-cli-pac0072-selection-classification.zip`
- `Releases/PAC-007.2/pac-cli-pac0072-qa-package.zip`

## Practical Next Step

Create `Current/PAC-007.3/STATUS.md` and define the memory commit contract before implementation.
