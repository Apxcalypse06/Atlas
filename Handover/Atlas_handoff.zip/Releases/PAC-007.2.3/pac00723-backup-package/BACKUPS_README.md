# Atlas Backups

This directory is reserved for full-project rollback snapshots.

## Purpose

Release archives preserve PAC deliverables.

Backup archives preserve the Atlas workspace state before structural changes.

## Required Practice

Before future structural PAC or PAC patch work, create a backup:

```bash
py tools/atlas_backup.py PAC-007.3
```

The backup tool writes a ZIP snapshot under:

```text
Backups/
```

## Scope

Backups are for rollback.

They are not release artifacts and should not replace PAC release archives or QA packages.

## Exclusions

The backup tool excludes:

- `.git`;
- `Backups`;
- Python cache directories;
- temporary packaging directories.

This prevents recursive backups and local cache noise.
