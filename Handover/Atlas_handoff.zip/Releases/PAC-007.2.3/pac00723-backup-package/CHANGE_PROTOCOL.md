# Atlas Change Protocol

## Rule

No structural Atlas change should be made without a PAC or PAC patch.

This applies to changes that affect:

- architecture;
- governance;
- manifest;
- README;
- entrypoints;
- current status files;
- release artifacts;
- QA packages;
- handover structure;
- memory architecture.

## Required Flow

Before editing structural Atlas files:

1. Identify the PAC or PAC patch.
2. Define why the change exists.
3. Define the files that will be added or updated.
4. Create a rollback backup.
5. Define the expected release archive.
6. Define the expected QA archive.
7. Apply the change.
8. Update `MANIFEST.json`.
9. Run `tools/atlas_validate.py`.

## Backup Requirement

Before future structural changes, run:

```bash
py tools/atlas_backup.py <PAC_ID>
```

Example:

```bash
py tools/atlas_backup.py PAC-007.3 --label before-memory-commit
```

Backups are written under:

```text
Backups/
```

Backup archives are rollback snapshots. They do not replace release archives or QA packages.

## Patch Requirements

Every PAC patch should include:

- `Current/<PAC_ID>/STATUS.md`;
- one release archive under `Releases/<PAC_ID>/`;
- one QA archive under `Releases/<PAC_ID>/`;
- a `MANIFEST.json` entry in `status`;
- a `MANIFEST.json` entry in `included_files`;
- a `MANIFEST.json` entry in `missing_files`.

## Naming

Patch PAC IDs may use dotted suffixes:

```text
PAC-007.2.1
PAC-007.2.2
```

The suffix should be used for governance or corrective patches that support a completed PAC without changing its main functional scope.

## Validation

Run:

```bash
py tools/atlas_validate.py
```

The validator should pass before a patch is considered complete.

## Non-goals

This protocol does not replace human review.

It prevents obvious untracked structural changes and makes future assistants start from the same discipline.
