# PAC-007.2.3 Change Note

## Date

2026-07-02

## Change

Added a backup and rollback protocol for Atlas.

## Added

- `BACKUPS/README.md`
- `tools/atlas_backup.py`
- `Current/PAC-007.2.3/STATUS.md`

## Updated

- `GOVERNANCE/CHANGE_PROTOCOL.md`
- `tools/atlas_validate.py`
- `START_HERE.md`
- `README/README.md`
- `MANIFEST.json`

## Reason

Atlas had release archives and QA packages, but no full-project rollback snapshot mechanism.

This patch adds a future-facing backup requirement and a local backup tool.

## Scope

Backup enforcement starts from PAC-007.2.3 for future structural changes.

This patch does not claim historical pre-change backups for already completed PACs.
