# PAC-007.2.3 - Backup & Rollback Protocol

Status: Done

## Purpose

Add a rollback backup protocol for future structural Atlas changes.

## Why This Patch Exists

Atlas had PAC release archives and QA packages, but no full-project rollback snapshots.

Release archives explain what was delivered.

Backups preserve a restorable workspace state before future structural changes.

## Added

- `BACKUPS/README.md`
- `tools/atlas_backup.py`
- `Current/PAC-007.2.3/STATUS.md`

## Updated

- `GOVERNANCE/CHANGE_PROTOCOL.md`
- `tools/atlas_validate.py`
- `START_HERE.md`
- `README/README.md`
- `MANIFEST.json`

## Backup Command

Before future structural PAC or PAC patch work:

```bash
py tools/atlas_backup.py <PAC_ID>
```

Example:

```bash
py tools/atlas_backup.py PAC-007.3 --label before-memory-commit
```

## Enforcement

`tools/atlas_validate.py` now checks that:

- `BACKUPS/README.md` exists;
- `tools/atlas_backup.py` exists;
- `MANIFEST.json.backup_policy` is declared;
- the backup policy points to the backup tool and directory.

## Important Note

This patch introduces backup enforcement for future structural changes starting from PAC-007.2.3.

It does not claim to provide historical pre-change backups for patches that were already completed.

## Non-goals

- no PAC-007.3 implementation;
- no memory commit;
- no handover generation;
- no change to PAC-007.2 selection behavior.
