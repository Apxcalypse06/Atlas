# Atlas

Atlas is a cognitive continuity subsystem.

Hierarchy:

```text
Global Project
`-- Future powerful / self-improving AI system
    `-- Atlas
        `-- Cognitive continuity ecosystem
            `-- PAC
                `-- Portable capsule and CLI tooling
```

## Mission

Atlas aims to ensure cognitive continuity based on information that is:

- traceable;
- verified;
- transmissible.

## Important clarification

The current `Atlas.zip` is not yet a fully living memory file.

It currently contains:

- architecture;
- releases;
- QA packages;
- reviews;
- handover material;
- project governance;
- PAC implementation artifacts.

It does not yet contain the future cognitive memory layer:

```text
user/memory.json
projects/<project_id>/memory.json
shared/memory.json
```

This memory layer is expected to emerge through:

- PAC-007.2 - Knowledge Selection & Classification;
- PAC-007.3 - Memory Commit;
- PAC-008 - Handover Generation.

## Current PAC status

- PAC-001: DONE
- PAC-002: DONE
- PAC-003: DONE
- PAC-004: DONE
- PAC-005: DONE
- PAC-006: DONE
- PAC-007.1: DONE
- PAC-007.2: FEATURE_COMPLETE
- PAC-007.2.1: DONE
- PAC-007.2.2: DONE
- PAC-007.2.3: DONE

## Change governance

Before structural Atlas changes, read:

```text
GOVERNANCE/CHANGE_PROTOCOL.md
```

Then run:

```bash
py tools/atlas_validate.py
```

Before future structural changes, create a rollback backup:

```bash
py tools/atlas_backup.py <PAC_ID>
```

## Current next step

PAC-007.3 - Memory Commit

Goal:

Commit selected PAC-007.2 candidates into the appropriate future memory domain:

1. user;
2. project;
3. shared.

PAC-007.3 should preserve PAC-007.2 provenance and must only commit selected candidates.
