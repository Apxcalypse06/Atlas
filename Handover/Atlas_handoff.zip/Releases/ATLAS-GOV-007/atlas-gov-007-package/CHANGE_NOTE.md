# ATLAS-GOV-007 Change Note

## Summary

`ATLAS-GOV-007` removes legacy `Current/PAC-007.2.x/` folders after their governance content was reclassified into `ATLAS-GOV-001` through `ATLAS-GOV-005`.

## Why

The duplicated current folders made the legacy governance patches appear to be active PAC work.

The historical release archives remain available under `Releases/PAC-007.2.x/`.

## Boundary

This is a governance cleanup only. It does not change PAC pipeline behavior.
