# ATLAS-GOV-007 Package Manifest

Archive:

```text
atlas-gov-007-legacy-current-cleanup.zip
```

## Purpose

Archive the cleanup that removes reclassified legacy governance folders from the active `Current/` surface while preserving release history.

## Included files

- `Current/ATLAS-GOV-007/STATUS.md`
- `README/README.md`
- `MANIFEST.json`
- `START_HERE.md`
- `tools/atlas_generate_start_here.py`

## Historical folders removed from Current

- `Current/PAC-007.2.1/`
- `Current/PAC-007.2.2/`
- `Current/PAC-007.2.3/`
- `Current/PAC-007.2.4/`
- `Current/PAC-007.2.5/`
