# ATLAS-GOV-006 Change Note

## Date

2026-07-02

## Change

Reclassifies governance patches out of the PAC-007.2 namespace.

## Mapping

```text
PAC-007.2.1 -> ATLAS-GOV-001
PAC-007.2.2 -> ATLAS-GOV-002
PAC-007.2.3 -> ATLAS-GOV-003
PAC-007.2.4 -> ATLAS-GOV-004
PAC-007.2.5 -> ATLAS-GOV-005
```

## Reason

`PAC-*` should describe the cognitive continuity pipeline.

`ATLAS-GOV-*` should describe Atlas governance, validation, backup, entrypoint, and taxonomy rules.

## Preservation

The previous `PAC-007.2.x` records are not erased.

They are marked as reclassified so historical references remain traceable.
