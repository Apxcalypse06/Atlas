# ATLAS-GOV-006 Package Manifest

## Package

`atlas-gov-006-governance-patch-reclassification.zip`

## Contents

- `CHANGE_NOTE.md`
- `STATUS.md`

## Purpose

Archive the governance patch reclassification from `PAC-007.2.x` to `ATLAS-GOV-*`.
