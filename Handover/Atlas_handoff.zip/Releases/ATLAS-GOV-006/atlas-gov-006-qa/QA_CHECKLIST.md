# ATLAS-GOV-006 QA Checklist

- [x] `ATLAS-GOV-001` status exists.
- [x] `ATLAS-GOV-002` status exists.
- [x] `ATLAS-GOV-003` status exists.
- [x] `ATLAS-GOV-004` status exists.
- [x] `ATLAS-GOV-005` status exists.
- [x] `ATLAS-GOV-006` status exists.
- [x] Reclassification mapping is documented.
- [x] Legacy PAC IDs are not erased.
- [x] Governance archives exist.
- [x] QA archives exist.
- [x] Atlas validation passes.
