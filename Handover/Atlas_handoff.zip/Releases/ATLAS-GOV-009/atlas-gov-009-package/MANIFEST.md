# ATLAS-GOV-009 Package Manifest

Archive:

```text
atlas-gov-009-memory-feedback-rule.zip
```

## Purpose

Archive the rule that assistants may keep stable user information without repeated consent prompts, but must say whether the information was recorded in Atlas.

## Included files

- `Current/ATLAS-GOV-009/STATUS.md`
- `GOVERNANCE/CHANGE_PROTOCOL.md`
- `README/README.md`
- `MANIFEST.json`
- `START_HERE.md`
- `tools/atlas_generate_start_here.py`
