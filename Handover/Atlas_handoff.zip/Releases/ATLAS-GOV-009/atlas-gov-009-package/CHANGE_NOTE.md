# ATLAS-GOV-009 Change Note

## Summary

`ATLAS-GOV-009` defines a memory feedback rule for future assistants.

Stable user information can be kept through the Atlas memory pipeline without asking for consent every time, but the assistant must tell the user whether it recorded the information in Atlas.

## Boundary

This is a governance behavior rule only. It does not add new PAC CLI behavior.
