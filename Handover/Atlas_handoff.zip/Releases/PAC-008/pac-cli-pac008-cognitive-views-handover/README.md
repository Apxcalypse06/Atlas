# PAC CLI - PAC-008 Cognitive Views & Handover

Reference implementation for PAC v0.2.

Current alpha version: `0.8.0-alpha`.

## Scope

PAC-008 generates cognitive views and a current handover from committed memory.

It consumes memory domain files produced by PAC-007.3 and writes derived view artifacts.

## Commands

```bash
pac session validate project.pac.zip --session SES-... --validated-by Tommy
pac session select project.pac.zip --session SES-... --selected-by Tommy
pac session commit project.pac.zip --session SES-... --committed-by Tommy
pac session handover project.pac.zip --generated-by Tommy
```

## Input

```text
user/memory.json
projects/<project_id>/memory.json
shared/memory.json
```

## Outputs

```text
views/current/user_memory_view.json
views/current/project_memory_view.json
views/current/shared_memory_view.json
views/current/cognitive_summary.json
handovers/current.md
```

## Handover behavior

- reads all committed memory entries;
- groups project memory by project id;
- preserves memory provenance in JSON views;
- writes a human-readable `handovers/current.md`;
- updates only capsule metadata and changelog in addition to generated artifacts.

## Source artifact boundary

PAC-008 must not modify source artifacts:

- source session file: unchanged;
- analysis artifact: unchanged;
- validation artifact: unchanged;
- selection artifact: unchanged.
- memory domain files: unchanged.

PAC-008 is allowed to update:

- generated view artifacts;
- generated handover artifact;
- `MANIFEST.json.updated_at`;
- `MANIFEST.json.latest_handover`;
- `MANIFEST.json.latest_cognitive_views`;
- `logs/changelog.md`.

## Non-goals

PAC-008 does not:

- decide KEEP / IGNORE;
- reclassify candidates;
- commit memory;
- edit committed memory entries;
- require an LLM.

## Test

```bash
pip install -e .
pytest -q
```
