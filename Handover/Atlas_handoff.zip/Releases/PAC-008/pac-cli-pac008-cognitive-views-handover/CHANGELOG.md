# Changelog

## v0.8.0-alpha (unreleased)

### Added

- `pac session handover`
- cognitive view generation from committed memory
- `views/current/user_memory_view.json`
- `views/current/project_memory_view.json`
- `views/current/shared_memory_view.json`
- `views/current/cognitive_summary.json`
- `handovers/current.md`
- tests for PAC-008 handover generation behavior
- CLI tests for `pac session handover`

### Clarified

- PAC-008 consumes committed memory after PAC-007.3.
- PAC-008 does not modify source memory files.
- PAC-008 writes derived view and handover artifacts.

### Non-goals

- no memory commit;
- no candidate reclassification;
- no LLM dependency.

## v0.7.3-alpha (unreleased)

### Added

- `pac session commit`
- memory commit pipeline
- domain memory writes for `user`, `project`, and `shared`
- idempotent commits from a selection artifact
- tests for PAC-007.3 memory commit behavior
- CLI tests for `pac session commit`

### Clarified

- PAC-007.3 commits only `keep=true` candidates.
- PAC-007.3 preserves provenance from session, analysis, validation, selection, and candidate source.
- PAC-007.3 does not modify source session, analysis, validation, or selection artifacts.

### Non-goals

- no KEEP / IGNORE decision logic;
- no candidate reclassification;
- no PAC-008 cognitive views;
- no handover generation.

## v0.7.2-alpha

### Added

- `pac session select`
- knowledge selection/classification pipeline
- `sessions/selection/<session_id>.selection.json`
- tests for PAC-007.2 selection behavior
- CLI tests for `pac session select`

### Clarified

- PAC-007.2 reads analysis and validation artifacts, then writes a new selection artifact.
- PAC-007.2 does not commit official memory.
- PAC-007.2 is append-only with respect to source session, analysis, validation and memory artifacts.

### Non-goals

- no direct writes to `user/memory.json`;
- no direct writes to `projects/<project_id>/memory.json`;
- no direct writes to `shared/memory.json`;
- no PAC-008 handover generation.

## v0.7.0-alpha

### Added

- `pac session validate`
- validation artifact pipeline
- `sessions/validation/<session_id>.validation.json`
- tests for session validation pipeline
- CLI tests for `pac session validate`

### Clarified

- PAC-007.1 is append-only with respect to source artifacts:
  - session source remains unchanged;
  - analysis artifact remains unchanged;
  - `user/memory.json` remains unchanged.
- `MANIFEST.json.updated_at` and `logs/changelog.md` may be updated as capsule metadata/logs.

### Non-goals

- no memory commit;
- no automatic acceptance/rejection;
- no required LLM dependency.

## v0.6.0-alpha

- `pac session analyze`
- proposed analysis artifacts under `sessions/analysis/`
