from pathlib import Path

from pac.cli import main


def test_cli_create_then_validate(tmp_path: Path, capsys):
    output = tmp_path / "cli-created.pac.zip"
    create_code = main(["create", "--owner", "Tommy", "--project", "Humanity Foundation", "--output", str(output)])
    assert create_code == 0
    assert output.exists()

    validate_code = main(["validate", str(output)])
    captured = capsys.readouterr()
    assert validate_code == 0
    assert "Result: VALID" in captured.out


def test_cli_create_refuses_existing_file_without_force(tmp_path: Path, capsys):
    output = tmp_path / "cli-created.pac.zip"
    assert main(["create", "--owner", "Tommy", "--project", "Humanity Foundation", "--output", str(output)]) == 0
    second_code = main(["create", "--owner", "Tommy", "--project", "Humanity Foundation", "--output", str(output)])
    captured = capsys.readouterr()
    assert second_code == 1
    assert "PAC031" in captured.out


def test_cli_create_allows_existing_file_with_force(tmp_path: Path):
    output = tmp_path / "cli-created.pac.zip"
    assert main(["create", "--owner", "Tommy", "--project", "Humanity Foundation", "--output", str(output)]) == 0
    assert main(["create", "--owner", "Tommy", "--project", "Humanity Foundation", "--output", str(output), "--force"]) == 0


def test_cli_validate_invalid_returns_1(tmp_path: Path):
    invalid = tmp_path / "invalid.txt"
    invalid.write_text("not a zip", encoding="utf-8")
    assert main(["validate", str(invalid)]) == 1
