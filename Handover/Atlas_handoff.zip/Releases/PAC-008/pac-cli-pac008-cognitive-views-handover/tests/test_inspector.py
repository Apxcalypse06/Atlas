from pathlib import Path

from pac.creator import CreateOptions, PacCreator
from pac.inspector import PacInspector


def test_inspect_valid_capsule(tmp_path: Path):
    output = tmp_path / "inspectable.pac.zip"
    PacCreator().create(CreateOptions(owner="Tommy", project="Humanity Foundation", output=output))

    report = PacInspector().inspect(output)

    assert report.validation_valid
    assert report.manifest is not None
    assert report.manifest.owner == "Tommy"
    assert report.manifest.project == "Humanity Foundation"
    assert "MANIFEST.json" in report.files
    assert not report.missing_files


def test_inspect_text_output_contains_core_metadata(tmp_path: Path):
    output = tmp_path / "inspectable.pac.zip"
    PacCreator().create(CreateOptions(owner="Tommy", project="Humanity Foundation", output=output))

    text = PacInspector().inspect(output).to_text()

    assert "PAC Capsule" in text
    assert "Project: Humanity Foundation" in text
    assert "Owner: Tommy" in text
    assert "Validation: VALID" in text
    assert "✓ MANIFEST.json" in text
