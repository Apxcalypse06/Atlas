import json
import zipfile
from pathlib import Path

import pytest

from pac.creator import CreateOptions, PacCreator
from pac.memory import MemoryAddOptions, PacMemoryManager
from pac.validator import PacValidator


def read_json(capsule: Path, path: str):
    with zipfile.ZipFile(capsule, "r") as archive:
        return json.loads(archive.read(path).decode("utf-8"))


def read_text(capsule: Path, path: str):
    with zipfile.ZipFile(capsule, "r") as archive:
        return archive.read(path).decode("utf-8")


def test_memory_add_updates_memory_json_and_keeps_capsule_valid(tmp_path: Path):
    capsule = tmp_path / "memory.pac.zip"
    PacCreator().create(CreateOptions(owner="Tommy", project="Humanity Foundation", output=capsule))

    result = PacMemoryManager().add(
        MemoryAddOptions(
            capsule=capsule,
            memory_type="decision",
            text="PAC-003 is DONE.",
        )
    )

    assert result.valid_after_update
    assert PacValidator().validate(capsule).valid

    memory = read_json(capsule, "user/memory.json")
    assert len(memory["memories"]) == 1
    assert memory["memories"][0]["id"] == result.memory_id
    assert memory["memories"][0]["type"] == "decision"
    assert memory["memories"][0]["text"] == "PAC-003 is DONE."


def test_memory_add_updates_changelog(tmp_path: Path):
    capsule = tmp_path / "memory.pac.zip"
    PacCreator().create(CreateOptions(owner="Tommy", project="Humanity Foundation", output=capsule))

    result = PacMemoryManager().add(
        MemoryAddOptions(capsule=capsule, memory_type="release", text="PAC-004 started.")
    )

    changelog = read_text(capsule, "logs/changelog.md")
    assert result.memory_id in changelog
    assert "Added memory" in changelog


def test_memory_add_updates_manifest_updated_at(tmp_path: Path):
    capsule = tmp_path / "memory.pac.zip"
    PacCreator().create(CreateOptions(owner="Tommy", project="Humanity Foundation", output=capsule))

    before = read_json(capsule, "MANIFEST.json")["updated_at"]

    PacMemoryManager().add(
        MemoryAddOptions(capsule=capsule, memory_type="note", text="A note.")
    )

    after = read_json(capsule, "MANIFEST.json")["updated_at"]
    assert after != before


def test_memory_add_rejects_unknown_type(tmp_path: Path):
    capsule = tmp_path / "memory.pac.zip"
    PacCreator().create(CreateOptions(owner="Tommy", project="Humanity Foundation", output=capsule))

    with pytest.raises(ValueError, match="memory type"):
        PacMemoryManager().add(
            MemoryAddOptions(capsule=capsule, memory_type="unknown", text="x")
        )


def test_memory_add_rejects_empty_text(tmp_path: Path):
    capsule = tmp_path / "memory.pac.zip"
    PacCreator().create(CreateOptions(owner="Tommy", project="Humanity Foundation", output=capsule))

    with pytest.raises(ValueError, match="text"):
        PacMemoryManager().add(
            MemoryAddOptions(capsule=capsule, memory_type="note", text=" ")
        )
