import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from pac.error_codes import ErrorCode
from pac.spec import PAC_PROTOCOL, PAC_VERSION, REQUIRED_READ_ORDER_V02
from pac.validator import PacValidator


def codes(report):
    return {issue.code for issue in report.errors}


def manifest(**overrides):
    data = {
        "format": "PAC",
        "protocol": PAC_PROTOCOL,
        "version": PAC_VERSION,
        "capsule_id": "PAC-" + str(uuid4()),
        "owner": "Tommy",
        "project": "Humanity Foundation",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "entrypoint": "00_INDEX.md",
        "required_read_order": REQUIRED_READ_ORDER_V02,
    }
    data.update(overrides)
    return data


def create_capsule(path: Path, *, manifest_data=None, manifest_raw=None, omit=()):
    files = {
        "00_INDEX.md": "# INDEX\n",
        "01_HANDOVER.md": "# HANDOVER\n",
        "security/consent_policy.md": "# Consent Policy\n",
        "user/profile.json": json.dumps({"preferred_name": "Tommy"}),
        "user/memory.json": json.dumps({"version": "0.2", "memories": []}),
        "projects/state.md": "# State\n",
        "projects/decisions.md": "# Decisions\n",
        "logs/changelog.md": "# Changelog\n",
    }
    for key in omit:
        files.pop(key, None)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        if manifest_raw is not None:
            z.writestr("MANIFEST.json", manifest_raw)
        elif manifest_data is not None:
            z.writestr("MANIFEST.json", json.dumps(manifest_data, ensure_ascii=False, indent=2))
        for name, content in files.items():
            z.writestr(name, content)


def test_valid_v02_capsule(tmp_path: Path):
    capsule = tmp_path / "valid.pac.zip"
    create_capsule(capsule, manifest_data=manifest())
    assert PacValidator().validate(capsule).valid


def test_missing_handover_capsule_is_invalid(tmp_path: Path):
    capsule = tmp_path / "missing_handover.pac.zip"
    create_capsule(capsule, manifest_data=manifest(), omit=("01_HANDOVER.md",))
    report = PacValidator().validate(capsule)
    assert not report.valid
    assert ErrorCode.REQUIRED_FILE_MISSING in codes(report)


def test_invalid_manifest_capsule_is_invalid(tmp_path: Path):
    capsule = tmp_path / "invalid_manifest.pac.zip"
    create_capsule(capsule, manifest_raw="{ invalid json")
    report = PacValidator().validate(capsule)
    assert not report.valid
    assert ErrorCode.MANIFEST_INVALID_JSON in codes(report)


def test_missing_manifest_is_invalid(tmp_path: Path):
    capsule = tmp_path / "missing_manifest.pac.zip"
    create_capsule(capsule)
    report = PacValidator().validate(capsule)
    assert not report.valid
    assert ErrorCode.MANIFEST_MISSING in codes(report)


def test_non_zip_is_invalid(tmp_path: Path):
    text = tmp_path / "not_zip.txt"
    text.write_text("not a zip", encoding="utf-8")
    report = PacValidator().validate(text)
    assert not report.valid
    assert ErrorCode.NOT_ZIP in codes(report)


def test_unsupported_version_is_invalid(tmp_path: Path):
    capsule = tmp_path / "unsupported_version.pac.zip"
    create_capsule(capsule, manifest_data=manifest(version="9.9"))
    report = PacValidator().validate(capsule)
    assert not report.valid
    assert ErrorCode.MANIFEST_FIELD_INVALID in codes(report) or ErrorCode.VERSION_UNSUPPORTED in codes(report)


def test_required_read_order_must_match_expected_order(tmp_path: Path):
    capsule = tmp_path / "bad_order.pac.zip"
    create_capsule(capsule, manifest_data=manifest(required_read_order=["MANIFEST.json"]))
    report = PacValidator().validate(capsule)
    assert not report.valid
    assert ErrorCode.MANIFEST_FIELD_INVALID in codes(report)


def test_protocol_must_match_expected_value(tmp_path: Path):
    capsule = tmp_path / "bad_protocol.pac.zip"
    create_capsule(capsule, manifest_data=manifest(protocol="Bad Protocol"))
    report = PacValidator().validate(capsule)
    assert not report.valid
    assert ErrorCode.MANIFEST_FIELD_INVALID in codes(report)


def test_manifest_does_not_coerce_non_string_fields(tmp_path: Path):
    capsule = tmp_path / "bad_owner_type.pac.zip"
    create_capsule(capsule, manifest_data=manifest(owner=123))
    report = PacValidator().validate(capsule)
    assert not report.valid
    assert ErrorCode.MANIFEST_FIELD_INVALID in codes(report)
