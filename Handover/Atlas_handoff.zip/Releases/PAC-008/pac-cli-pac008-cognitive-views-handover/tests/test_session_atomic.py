import json, zipfile
from pathlib import Path
from pac.creator import CreateOptions, PacCreator
from pac.session import PacSessionImporter, SessionImportOptions

def read(capsule: Path, path: str) -> bytes:
    with zipfile.ZipFile(capsule, 'r') as z: return z.read(path)

def names(capsule: Path):
    with zipfile.ZipFile(capsule, 'r') as z: return set(z.namelist())

def rewrite_with(capsule: Path, updates: dict[str, bytes]):
    with zipfile.ZipFile(capsule, 'r') as z: files={n:z.read(n) for n in z.namelist()}
    files.update(updates)
    with zipfile.ZipFile(capsule, 'w', zipfile.ZIP_DEFLATED) as z:
        for n,b in files.items(): z.writestr(n,b)

def test_failed_import_does_not_partially_modify_capsule(tmp_path: Path):
    cap=tmp_path/'cap.pac.zip'; src=tmp_path/'chat.txt'; src.write_text('hello')
    PacCreator().create(CreateOptions(owner='Tommy', project='HF', output=cap))
    before_names=names(cap); before_log=read(cap,'logs/changelog.md')
    rewrite_with(cap, {'user/memory.json': b'{ invalid json'})
    bad_memory=read(cap,'user/memory.json')
    try:
        PacSessionImporter().import_session(SessionImportOptions(source=src, capsule=cap, force=True))
    except ValueError as e:
        assert 'user/memory.json is invalid JSON' in str(e)
    else:
        raise AssertionError('expected ValueError')
    assert names(cap)==before_names
    assert read(cap,'logs/changelog.md')==before_log
    assert read(cap,'user/memory.json')==bad_memory

def test_multiple_imports_append_to_index(tmp_path: Path):
    cap=tmp_path/'cap.pac.zip'; a=tmp_path/'a.txt'; b=tmp_path/'b.txt'; a.write_text('a'); b.write_text('b')
    PacCreator().create(CreateOptions(owner='Tommy', project='HF', output=cap))
    PacSessionImporter().import_session(SessionImportOptions(source=a, capsule=cap))
    PacSessionImporter().import_session(SessionImportOptions(source=b, capsule=cap))
    idx=json.loads(read(cap,'sessions/index.json').decode())
    assert len(idx['sessions'])==2

def test_import_without_suffix_uses_txt(tmp_path: Path):
    cap=tmp_path/'cap.pac.zip'; src=tmp_path/'chat'; src.write_text('hello')
    PacCreator().create(CreateOptions(owner='Tommy', project='HF', output=cap))
    result=PacSessionImporter().import_session(SessionImportOptions(source=src, capsule=cap))
    assert result.session_path.endswith('.txt')
