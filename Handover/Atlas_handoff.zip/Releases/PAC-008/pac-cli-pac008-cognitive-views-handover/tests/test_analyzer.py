import json, zipfile
from pathlib import Path
import pytest
from pac.analyzer import PacSessionAnalyzer, SessionAnalyzeOptions
from pac.creator import CreateOptions, PacCreator
from pac.session import PacSessionImporter, SessionImportOptions
from pac.validator import PacValidator

def read_json(capsule: Path, path: str):
    with zipfile.ZipFile(capsule, "r") as z: return json.loads(z.read(path).decode())
def names(capsule: Path):
    with zipfile.ZipFile(capsule, "r") as z: return set(z.namelist())
def make(tmp_path: Path):
    cap=tmp_path/'analysis.pac.zip'; src=tmp_path/'chat.txt'; src.write_text('Decision: continue PAC-006. Task: implement analyzer.', encoding='utf-8')
    PacCreator().create(CreateOptions(owner='Tommy', project='Atlas', output=cap))
    imp=PacSessionImporter().import_session(SessionImportOptions(source=src, capsule=cap, label='PAC-006 test'))
    return cap, imp.session_id

def test_analyze_imported_session_creates_analysis_file(tmp_path: Path):
    cap,sid=make(tmp_path)
    result=PacSessionAnalyzer().analyze(SessionAnalyzeOptions(capsule=cap, session_id=sid))
    assert result.valid_after_update
    assert PacValidator().validate(cap).valid
    assert result.analysis_path in names(cap)
    analysis=read_json(cap,result.analysis_path)
    assert analysis['version']=='0.1'
    assert analysis['session_id']==sid
    assert analysis['status']=='proposed'
    assert isinstance(analysis['decisions'], list)
    assert isinstance(analysis['tasks'], list)
    assert isinstance(analysis['principles'], list)
    assert analysis['source_path'].startswith('sessions/')

def test_analyze_does_not_modify_official_memory(tmp_path: Path):
    cap,sid=make(tmp_path)
    before=read_json(cap,'user/memory.json')
    PacSessionAnalyzer().analyze(SessionAnalyzeOptions(capsule=cap, session_id=sid))
    after=read_json(cap,'user/memory.json')
    assert after==before

def test_analyze_unknown_session_is_rejected(tmp_path: Path):
    cap,_=make(tmp_path)
    with pytest.raises(ValueError, match='session not found'):
        PacSessionAnalyzer().analyze(SessionAnalyzeOptions(capsule=cap, session_id='SES-does-not-exist'))

def test_analyze_rejects_invalid_session_id_format(tmp_path: Path):
    cap,_=make(tmp_path)
    with pytest.raises(ValueError, match='session_id'):
        PacSessionAnalyzer().analyze(SessionAnalyzeOptions(capsule=cap, session_id='bad'))
