import json
import zipfile
from pathlib import Path

import pytest

from pac.analyzer import PacSessionAnalyzer, SessionAnalyzeOptions
from pac.creator import CreateOptions, PacCreator
from pac.selector import PacKnowledgeSelector, SessionSelectOptions
from pac.session import PacSessionImporter, SessionImportOptions
from pac.session_validator import PacSessionValidationPipeline, SessionValidateOptions
from pac.validator import PacValidator


def read_json(capsule: Path, path: str):
    with zipfile.ZipFile(capsule, "r") as z:
        return json.loads(z.read(path).decode())


def read_bytes(capsule: Path, path: str) -> bytes:
    with zipfile.ZipFile(capsule, "r") as z:
        return z.read(path)


def names(capsule: Path):
    with zipfile.ZipFile(capsule, "r") as z:
        return set(z.namelist())


def replace_json(capsule: Path, path: str, data):
    with zipfile.ZipFile(capsule, "r") as z:
        existing = {name: z.read(name) for name in z.namelist()}
    existing[path] = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
    tmp = capsule.with_name(capsule.name + ".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for name, content in existing.items():
            z.writestr(name, content)
    tmp.replace(capsule)


def make_validated_capsule(tmp_path: Path):
    cap = tmp_path / "selection.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation for selection.", encoding="utf-8")
    PacCreator().create(CreateOptions(owner="Tommy", project="Atlas", output=cap))
    imported = PacSessionImporter().import_session(SessionImportOptions(source=src, capsule=cap, label="PAC-007.2 test"))
    PacSessionAnalyzer().analyze(SessionAnalyzeOptions(capsule=cap, session_id=imported.session_id))
    analysis_path = f"sessions/analysis/{imported.session_id}.analysis.json"
    analysis = read_json(cap, analysis_path)
    analysis["decisions"] = ["PAC-007.2 selects knowledge before memory commit."]
    analysis["tasks"] = [{"text": "Prepare PAC-007.3 memory commit after selection."}]
    analysis["questions"] = ["Should handover generation be PAC-008?"]
    analysis["principles"] = [{"statement": "Artifacts do not modify source artifacts.", "category": "shared"}]
    analysis["evidence"] = [{"statement": "Tommy prefers concise handovers.", "category": "user"}]
    replace_json(cap, analysis_path, analysis)
    PacSessionValidationPipeline().validate_session(
        SessionValidateOptions(capsule=cap, session_id=imported.session_id, validated_by="Tommy")
    )
    return cap, imported.session_id


def test_select_session_creates_selection_artifact(tmp_path: Path):
    cap, sid = make_validated_capsule(tmp_path)
    result = PacKnowledgeSelector().select(SessionSelectOptions(capsule=cap, session_id=sid, selected_by="Tommy"))

    assert result.valid_after_update
    assert result.selection_path == f"sessions/selection/{sid}.selection.json"
    assert result.selection_path in names(cap)
    assert result.selected_count == 4
    assert result.ignored_count == 1
    assert PacValidator().validate(cap).valid

    selection = read_json(cap, result.selection_path)
    assert selection["status"] == "classified"
    assert selection["source_analysis_path"] == f"sessions/analysis/{sid}.analysis.json"
    assert selection["source_validation_path"] == f"sessions/validation/{sid}.validation.json"
    assert selection["candidates"][0] == {
        "statement": "PAC-007.2 selects knowledge before memory commit.",
        "keep": True,
        "category": "project",
        "project_id": "Atlas",
        "reason": "Decision relevant to project continuity",
        "source": {"analysis_field": "decisions", "index": 0},
    }
    assert selection["candidates"][2]["keep"] is False
    assert selection["candidates"][2]["category"] is None
    assert selection["candidates"][3]["category"] == "shared"
    assert selection["candidates"][4]["category"] == "user"


def test_select_session_does_not_modify_sources_or_memory(tmp_path: Path):
    cap, sid = make_validated_capsule(tmp_path)
    session_path = read_json(cap, "sessions/index.json")["sessions"][0]["path"]
    analysis_path = f"sessions/analysis/{sid}.analysis.json"
    validation_path = f"sessions/validation/{sid}.validation.json"
    before_session = read_bytes(cap, session_path)
    before_analysis = read_bytes(cap, analysis_path)
    before_validation = read_bytes(cap, validation_path)
    before_memory = read_bytes(cap, "user/memory.json")

    PacKnowledgeSelector().select(SessionSelectOptions(capsule=cap, session_id=sid, selected_by="Tommy"))

    assert read_bytes(cap, session_path) == before_session
    assert read_bytes(cap, analysis_path) == before_analysis
    assert read_bytes(cap, validation_path) == before_validation
    assert read_bytes(cap, "user/memory.json") == before_memory


def test_select_session_requires_validation(tmp_path: Path):
    cap = tmp_path / "selection.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation without validation.", encoding="utf-8")
    PacCreator().create(CreateOptions(owner="Tommy", project="Atlas", output=cap))
    imported = PacSessionImporter().import_session(SessionImportOptions(source=src, capsule=cap))
    PacSessionAnalyzer().analyze(SessionAnalyzeOptions(capsule=cap, session_id=imported.session_id))

    with pytest.raises(ValueError, match="validation file missing"):
        PacKnowledgeSelector().select(SessionSelectOptions(capsule=cap, session_id=imported.session_id, selected_by="Tommy"))


def test_select_session_rejects_empty_selector(tmp_path: Path):
    cap, sid = make_validated_capsule(tmp_path)
    with pytest.raises(ValueError, match="selected_by"):
        PacKnowledgeSelector().select(SessionSelectOptions(capsule=cap, session_id=sid, selected_by=" "))
