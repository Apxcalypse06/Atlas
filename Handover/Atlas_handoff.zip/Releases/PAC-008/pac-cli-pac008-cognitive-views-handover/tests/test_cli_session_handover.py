import json
import zipfile
from pathlib import Path

from pac.cli import main


def test_cli_session_handover(tmp_path: Path, capsys):
    cap = tmp_path / "cli-handover.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation to hand over.", encoding="utf-8")
    assert main(["create", "--owner", "Tommy", "--project", "Atlas", "--output", str(cap)]) == 0
    assert main(["session", "import", str(src), "--capsule", str(cap), "--label", "Chat"]) == 0
    with zipfile.ZipFile(cap, "r") as z:
        sid = json.loads(z.read("sessions/index.json").decode())["sessions"][0]["id"]
    assert main(["session", "analyze", str(cap), "--session", sid]) == 0
    assert main(["session", "validate", str(cap), "--session", sid, "--validated-by", "Tommy"]) == 0
    assert main(["session", "select", str(cap), "--session", sid, "--selected-by", "Tommy"]) == 0
    assert main(["session", "commit", str(cap), "--session", sid, "--committed-by", "Tommy"]) == 0

    code = main(["session", "handover", str(cap), "--generated-by", "Tommy"])
    out = capsys.readouterr().out

    assert code == 0
    assert "Cognitive views generated" in out
    assert "View: views/current/cognitive_summary.json" in out
    assert "Handover: handovers/current.md" in out
    assert "Capsule valid: yes" in out


def test_cli_session_handover_missing_capsule_returns_1(tmp_path: Path):
    cap = tmp_path / "missing.pac.zip"

    assert main(["session", "handover", str(cap), "--generated-by", "Tommy"]) == 1
