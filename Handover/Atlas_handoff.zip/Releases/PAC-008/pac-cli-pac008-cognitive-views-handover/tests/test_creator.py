from pathlib import Path

import pytest

from pac.creator import CreateOptions, PacCreator
from pac.validator import PacValidator


def test_created_capsule_is_valid(tmp_path: Path):
    output = tmp_path / "created.pac.zip"
    PacCreator().create(CreateOptions(owner="Tommy", project="Humanity Foundation", output=output))
    report = PacValidator().validate(output)
    assert report.valid
    assert not report.errors


def test_creator_rejects_empty_owner(tmp_path: Path):
    with pytest.raises(ValueError, match="owner"):
        PacCreator().create(CreateOptions(owner=" ", project="Project", output=tmp_path / "created.pac.zip"))


def test_creator_rejects_empty_project(tmp_path: Path):
    with pytest.raises(ValueError, match="project"):
        PacCreator().create(CreateOptions(owner="Tommy", project=" ", output=tmp_path / "created.pac.zip"))


def test_creator_requires_pac_zip_extension(tmp_path: Path):
    with pytest.raises(ValueError, match=".pac.zip"):
        PacCreator().create(CreateOptions(owner="Tommy", project="Project", output=tmp_path / "created.zip"))


def test_creator_refuses_overwrite_without_force(tmp_path: Path):
    output = tmp_path / "created.pac.zip"
    output.write_text("existing", encoding="utf-8")
    with pytest.raises(FileExistsError, match="PAC031"):
        PacCreator().create(CreateOptions(owner="Tommy", project="Project", output=output))


def test_creator_overwrites_with_force(tmp_path: Path):
    output = tmp_path / "created.pac.zip"
    output.write_text("existing", encoding="utf-8")
    PacCreator().create(CreateOptions(owner="Tommy", project="Project", output=output, force=True))
    assert PacValidator().validate(output).valid
