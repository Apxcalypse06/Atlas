import json, zipfile
from pathlib import Path
from pac.cli import main

def test_cli_session_analyze(tmp_path: Path, capsys):
    cap=tmp_path/'cli-analysis.pac.zip'; src=tmp_path/'chat.txt'; src.write_text('Conversation to analyze.', encoding='utf-8')
    assert main(['create','--owner','Tommy','--project','Atlas','--output',str(cap)])==0
    assert main(['session','import',str(src),'--capsule',str(cap),'--label','Chat'])==0
    with zipfile.ZipFile(cap,'r') as z:
        sid=json.loads(z.read('sessions/index.json').decode())['sessions'][0]['id']
    code=main(['session','analyze',str(cap),'--session',sid])
    out=capsys.readouterr().out
    assert code==0
    assert 'Session analyzed:' in out
    assert 'Capsule valid: yes' in out
    with zipfile.ZipFile(cap,'r') as z:
        assert f'sessions/analysis/{sid}.analysis.json' in z.namelist()

def test_cli_session_analyze_unknown_session_returns_1(tmp_path: Path):
    cap=tmp_path/'cli-analysis.pac.zip'
    assert main(['create','--owner','Tommy','--project','Atlas','--output',str(cap)])==0
    assert main(['session','analyze',str(cap),'--session','SES-unknown'])==1
