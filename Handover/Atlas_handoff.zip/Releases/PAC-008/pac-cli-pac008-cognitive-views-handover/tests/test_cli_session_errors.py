import zipfile
from pathlib import Path
from pac.cli import main

def test_force_non_zip_returns_1_without_traceback(tmp_path: Path, capsys):
    src=tmp_path/'chat.txt'; src.write_text('hello')
    cap=tmp_path/'bad.pac.zip'; cap.write_text('not zip')
    code=main(['session','import',str(src),'--capsule',str(cap),'--force'])
    out=capsys.readouterr().out
    assert code==1
    assert 'Error:' in out
    assert 'Traceback' not in out

def test_force_zip_without_manifest_returns_1_without_traceback(tmp_path: Path, capsys):
    src=tmp_path/'chat.txt'; src.write_text('hello')
    cap=tmp_path/'bad.pac.zip'
    with zipfile.ZipFile(cap,'w',zipfile.ZIP_DEFLATED) as z: z.writestr('hello.txt','hello')
    code=main(['session','import',str(src),'--capsule',str(cap),'--force'])
    out=capsys.readouterr().out
    assert code==1
    assert 'Error:' in out
    assert 'Traceback' not in out
