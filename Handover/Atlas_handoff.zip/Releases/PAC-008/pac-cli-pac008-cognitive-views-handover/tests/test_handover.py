import json
import zipfile
from pathlib import Path

from pac.analyzer import PacSessionAnalyzer, SessionAnalyzeOptions
from pac.committer import PacMemoryCommitter, SessionCommitOptions
from pac.creator import CreateOptions, PacCreator
from pac.handover import HandoverGenerateOptions, PacCognitiveViewGenerator
from pac.selector import PacKnowledgeSelector, SessionSelectOptions
from pac.session import PacSessionImporter, SessionImportOptions
from pac.session_validator import PacSessionValidationPipeline, SessionValidateOptions
from pac.validator import PacValidator


def read_json(capsule: Path, path: str):
    with zipfile.ZipFile(capsule, "r") as z:
        return json.loads(z.read(path).decode())


def read_bytes(capsule: Path, path: str) -> bytes:
    with zipfile.ZipFile(capsule, "r") as z:
        return z.read(path)


def names(capsule: Path):
    with zipfile.ZipFile(capsule, "r") as z:
        return set(z.namelist())


def replace_json(capsule: Path, path: str, data):
    with zipfile.ZipFile(capsule, "r") as z:
        existing = {name: z.read(name) for name in z.namelist()}
    existing[path] = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
    tmp = capsule.with_name(capsule.name + ".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for name, content in existing.items():
            z.writestr(name, content)
    tmp.replace(capsule)


def make_committed_capsule(tmp_path: Path):
    cap = tmp_path / "handover.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation for generated handover.", encoding="utf-8")
    PacCreator().create(CreateOptions(owner="Tommy", project="Atlas", output=cap))
    imported = PacSessionImporter().import_session(SessionImportOptions(source=src, capsule=cap, label="PAC-008 test"))
    PacSessionAnalyzer().analyze(SessionAnalyzeOptions(capsule=cap, session_id=imported.session_id))
    PacSessionValidationPipeline().validate_session(
        SessionValidateOptions(capsule=cap, session_id=imported.session_id, validated_by="Tommy")
    )
    PacKnowledgeSelector().select(SessionSelectOptions(capsule=cap, session_id=imported.session_id, selected_by="Tommy"))

    selection_path = f"sessions/selection/{imported.session_id}.selection.json"
    selection = read_json(cap, selection_path)
    selection["candidates"] = [
        {
            "statement": "Tommy prefers continuity-focused memory.",
            "keep": True,
            "category": "user",
            "project_id": None,
            "reason": "Stable user preference relevant to continuity",
            "source": {"analysis_field": "evidence", "index": 0},
        },
        {
            "statement": "PAC-008 generates cognitive views from committed memory.",
            "keep": True,
            "category": "project",
            "project_id": "Atlas",
            "reason": "Pipeline capability",
            "source": {"analysis_field": "decisions", "index": 0},
        },
        {
            "statement": "Generated artifacts do not replace their source memory.",
            "keep": True,
            "category": "shared",
            "project_id": None,
            "reason": "Shared Atlas invariant",
            "source": {"analysis_field": "principles", "index": 0},
        },
    ]
    replace_json(cap, selection_path, selection)
    PacMemoryCommitter().commit(SessionCommitOptions(capsule=cap, session_id=imported.session_id, committed_by="Tommy"))
    return cap


def test_generate_handover_writes_views_and_handover(tmp_path: Path):
    cap = make_committed_capsule(tmp_path)
    result = PacCognitiveViewGenerator().generate(HandoverGenerateOptions(capsule=cap, generated_by="Tommy"))

    assert result.valid_after_update
    assert result.memory_count == 3
    assert result.handover_path == "handovers/current.md"
    assert set(result.view_paths) == {
        "views/current/user_memory_view.json",
        "views/current/project_memory_view.json",
        "views/current/shared_memory_view.json",
        "views/current/cognitive_summary.json",
    }
    assert set(result.view_paths) | {"handovers/current.md"} <= names(cap)
    assert PacValidator().validate(cap).valid

    summary = read_json(cap, "views/current/cognitive_summary.json")
    project = read_json(cap, "views/current/project_memory_view.json")
    assert summary["memory_count"] == 3
    assert summary["domains"] == {"user": 1, "project": 1, "shared": 1}
    assert project["projects"][0]["project_id"] == "Atlas"
    assert project["projects"][0]["entries"][0]["statement"] == "PAC-008 generates cognitive views from committed memory."

    with zipfile.ZipFile(cap, "r") as z:
        handover = z.read("handovers/current.md").decode("utf-8")
    assert "# Cognitive Handover" in handover
    assert "PAC-008 generates cognitive views from committed memory." in handover


def test_generate_handover_does_not_modify_memory_sources(tmp_path: Path):
    cap = make_committed_capsule(tmp_path)
    before_user = read_bytes(cap, "user/memory.json")
    before_project = read_bytes(cap, "projects/Atlas/memory.json")
    before_shared = read_bytes(cap, "shared/memory.json")

    PacCognitiveViewGenerator().generate(HandoverGenerateOptions(capsule=cap, generated_by="Tommy"))

    assert read_bytes(cap, "user/memory.json") == before_user
    assert read_bytes(cap, "projects/Atlas/memory.json") == before_project
    assert read_bytes(cap, "shared/memory.json") == before_shared


def test_generate_handover_accepts_empty_memory_capsule(tmp_path: Path):
    cap = tmp_path / "empty.pac.zip"
    PacCreator().create(CreateOptions(owner="Tommy", project="Atlas", output=cap))

    result = PacCognitiveViewGenerator().generate(HandoverGenerateOptions(capsule=cap, generated_by="Tommy"))

    assert result.valid_after_update
    assert result.memory_count == 0
    assert read_json(cap, "views/current/cognitive_summary.json")["memory_count"] == 0
