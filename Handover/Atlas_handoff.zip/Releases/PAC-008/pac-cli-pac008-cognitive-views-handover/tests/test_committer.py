import json
import zipfile
from pathlib import Path

import pytest

from pac.analyzer import PacSessionAnalyzer, SessionAnalyzeOptions
from pac.committer import PacMemoryCommitter, SessionCommitOptions
from pac.creator import CreateOptions, PacCreator
from pac.selector import PacKnowledgeSelector, SessionSelectOptions
from pac.session import PacSessionImporter, SessionImportOptions
from pac.session_validator import PacSessionValidationPipeline, SessionValidateOptions
from pac.validator import PacValidator


def read_json(capsule: Path, path: str):
    with zipfile.ZipFile(capsule, "r") as z:
        return json.loads(z.read(path).decode())


def read_bytes(capsule: Path, path: str) -> bytes:
    with zipfile.ZipFile(capsule, "r") as z:
        return z.read(path)


def names(capsule: Path):
    with zipfile.ZipFile(capsule, "r") as z:
        return set(z.namelist())


def replace_json(capsule: Path, path: str, data):
    with zipfile.ZipFile(capsule, "r") as z:
        existing = {name: z.read(name) for name in z.namelist()}
    existing[path] = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
    tmp = capsule.with_name(capsule.name + ".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for name, content in existing.items():
            z.writestr(name, content)
    tmp.replace(capsule)


def make_selected_capsule(tmp_path: Path):
    cap = tmp_path / "commit.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation for memory commit.", encoding="utf-8")
    PacCreator().create(CreateOptions(owner="Tommy", project="Atlas", output=cap))
    imported = PacSessionImporter().import_session(SessionImportOptions(source=src, capsule=cap, label="PAC-007.3 test"))
    PacSessionAnalyzer().analyze(SessionAnalyzeOptions(capsule=cap, session_id=imported.session_id))
    PacSessionValidationPipeline().validate_session(
        SessionValidateOptions(capsule=cap, session_id=imported.session_id, validated_by="Tommy")
    )
    PacKnowledgeSelector().select(SessionSelectOptions(capsule=cap, session_id=imported.session_id, selected_by="Tommy"))
    selection_path = f"sessions/selection/{imported.session_id}.selection.json"
    selection = read_json(cap, selection_path)
    selection["candidates"] = [
        {
            "statement": "Tommy prefers continuity-focused memory.",
            "keep": True,
            "category": "user",
            "project_id": None,
            "reason": "Stable user preference relevant to continuity",
            "source": {"analysis_field": "evidence", "index": 0},
        },
        {
            "statement": "PAC-007.3 commits selected candidates to memory.",
            "keep": True,
            "category": "project",
            "project_id": "Atlas",
            "reason": "Architecture decision relevant to project continuity",
            "source": {"analysis_field": "decisions", "index": 0},
        },
        {
            "statement": "Artifacts never modify their source artifacts.",
            "keep": True,
            "category": "shared",
            "project_id": None,
            "reason": "Shared Atlas principle",
            "source": {"analysis_field": "principles", "index": 0},
        },
        {
            "statement": "ok",
            "keep": False,
            "category": None,
            "project_id": None,
            "reason": "No continuity value",
            "source": {"analysis_field": "questions", "index": 0},
        },
    ]
    replace_json(cap, selection_path, selection)
    return cap, imported.session_id


def test_commit_session_writes_memory_domains(tmp_path: Path):
    cap, sid = make_selected_capsule(tmp_path)
    result = PacMemoryCommitter().commit(SessionCommitOptions(capsule=cap, session_id=sid, committed_by="Tommy"))

    assert result.valid_after_update
    assert result.committed_count == 3
    assert result.skipped_count == 1
    assert result.memory_paths == (
        "projects/Atlas/memory.json",
        "shared/memory.json",
        "user/memory.json",
    )
    assert PacValidator().validate(cap).valid
    assert {"user/memory.json", "projects/Atlas/memory.json", "shared/memory.json"} <= names(cap)

    user_memory = read_json(cap, "user/memory.json")
    project_memory = read_json(cap, "projects/Atlas/memory.json")
    shared_memory = read_json(cap, "shared/memory.json")

    assert user_memory["memories"][-1]["statement"] == "Tommy prefers continuity-focused memory."
    assert project_memory["domain"] == "project"
    assert project_memory["project_id"] == "Atlas"
    assert project_memory["memories"][0]["statement"] == "PAC-007.3 commits selected candidates to memory."
    assert shared_memory["memories"][0]["statement"] == "Artifacts never modify their source artifacts."
    assert project_memory["memories"][0]["source"]["selection_path"] == f"sessions/selection/{sid}.selection.json"
    assert project_memory["memories"][0]["source"]["source_analysis_path"] == f"sessions/analysis/{sid}.analysis.json"
    assert project_memory["memories"][0]["source"]["source_validation_path"] == f"sessions/validation/{sid}.validation.json"


def test_commit_session_does_not_modify_source_artifacts(tmp_path: Path):
    cap, sid = make_selected_capsule(tmp_path)
    session_path = read_json(cap, "sessions/index.json")["sessions"][0]["path"]
    analysis_path = f"sessions/analysis/{sid}.analysis.json"
    validation_path = f"sessions/validation/{sid}.validation.json"
    selection_path = f"sessions/selection/{sid}.selection.json"
    before_session = read_bytes(cap, session_path)
    before_analysis = read_bytes(cap, analysis_path)
    before_validation = read_bytes(cap, validation_path)
    before_selection = read_bytes(cap, selection_path)

    PacMemoryCommitter().commit(SessionCommitOptions(capsule=cap, session_id=sid, committed_by="Tommy"))

    assert read_bytes(cap, session_path) == before_session
    assert read_bytes(cap, analysis_path) == before_analysis
    assert read_bytes(cap, validation_path) == before_validation
    assert read_bytes(cap, selection_path) == before_selection


def test_commit_session_is_idempotent_for_same_selection(tmp_path: Path):
    cap, sid = make_selected_capsule(tmp_path)
    first = PacMemoryCommitter().commit(SessionCommitOptions(capsule=cap, session_id=sid, committed_by="Tommy"))
    second = PacMemoryCommitter().commit(SessionCommitOptions(capsule=cap, session_id=sid, committed_by="Tommy"))

    assert first.committed_count == 3
    assert second.committed_count == 0
    assert second.skipped_count == 4
    assert len(read_json(cap, "projects/Atlas/memory.json")["memories"]) == 1
    assert len(read_json(cap, "shared/memory.json")["memories"]) == 1


def test_commit_session_requires_selection(tmp_path: Path):
    cap = tmp_path / "commit.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation without selection.", encoding="utf-8")
    PacCreator().create(CreateOptions(owner="Tommy", project="Atlas", output=cap))
    imported = PacSessionImporter().import_session(SessionImportOptions(source=src, capsule=cap))

    with pytest.raises(ValueError, match="selection file missing"):
        PacMemoryCommitter().commit(SessionCommitOptions(capsule=cap, session_id=imported.session_id, committed_by="Tommy"))


def test_commit_session_rejects_path_traversal_project_id(tmp_path: Path):
    cap, sid = make_selected_capsule(tmp_path)
    selection_path = f"sessions/selection/{sid}.selection.json"
    selection = read_json(cap, selection_path)
    selection["candidates"][1]["project_id"] = "../Atlas"
    replace_json(cap, selection_path, selection)

    with pytest.raises(ValueError, match="project_id"):
        PacMemoryCommitter().commit(SessionCommitOptions(capsule=cap, session_id=sid, committed_by="Tommy"))
