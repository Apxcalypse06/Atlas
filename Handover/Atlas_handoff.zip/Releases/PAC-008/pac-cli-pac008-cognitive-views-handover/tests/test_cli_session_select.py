import json
import zipfile
from pathlib import Path

from pac.cli import main


def test_cli_session_select(tmp_path: Path, capsys):
    cap = tmp_path / "cli-selection.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation to select.", encoding="utf-8")
    assert main(["create", "--owner", "Tommy", "--project", "Atlas", "--output", str(cap)]) == 0
    assert main(["session", "import", str(src), "--capsule", str(cap), "--label", "Chat"]) == 0
    with zipfile.ZipFile(cap, "r") as z:
        sid = json.loads(z.read("sessions/index.json").decode())["sessions"][0]["id"]
    assert main(["session", "analyze", str(cap), "--session", sid]) == 0
    assert main(["session", "validate", str(cap), "--session", sid, "--validated-by", "Tommy"]) == 0

    code = main(["session", "select", str(cap), "--session", sid, "--selected-by", "Tommy"])
    out = capsys.readouterr().out

    assert code == 0
    assert "Session selection created:" in out
    assert "Selected candidates:" in out
    assert "Ignored candidates:" in out
    assert "Capsule valid: yes" in out
    with zipfile.ZipFile(cap, "r") as z:
        assert f"sessions/selection/{sid}.selection.json" in z.namelist()


def test_cli_session_select_without_validation_returns_1(tmp_path: Path):
    cap = tmp_path / "cli-selection.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation to select.", encoding="utf-8")
    assert main(["create", "--owner", "Tommy", "--project", "Atlas", "--output", str(cap)]) == 0
    assert main(["session", "import", str(src), "--capsule", str(cap)]) == 0
    with zipfile.ZipFile(cap, "r") as z:
        sid = json.loads(z.read("sessions/index.json").decode())["sessions"][0]["id"]
    assert main(["session", "analyze", str(cap), "--session", sid]) == 0

    assert main(["session", "select", str(cap), "--session", sid, "--selected-by", "Tommy"]) == 1
