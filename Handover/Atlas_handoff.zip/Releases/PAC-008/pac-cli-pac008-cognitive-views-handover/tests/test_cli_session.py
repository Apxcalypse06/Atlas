import json
import zipfile
from pathlib import Path

from pac.cli import main


def test_cli_session_import(tmp_path: Path, capsys):
    capsule = tmp_path / "cli-session.pac.zip"
    source = tmp_path / "chat.txt"
    source.write_text("conversation text", encoding="utf-8")

    assert main(["create", "--owner", "Tommy", "--project", "Humanity Foundation", "--output", str(capsule)]) == 0

    code = main(["session", "import", str(source), "--capsule", str(capsule), "--label", "Chat"])

    captured = capsys.readouterr()

    assert code == 0
    assert "Session imported:" in captured.out
    assert "Capsule valid: yes" in captured.out

    with zipfile.ZipFile(capsule, "r") as archive:
        names = set(archive.namelist())
        assert "sessions/index.json" in names
        index = json.loads(archive.read("sessions/index.json").decode("utf-8"))
        assert len(index["sessions"]) == 1


def test_cli_session_import_missing_file_returns_1(tmp_path: Path):
    capsule = tmp_path / "cli-session.pac.zip"
    assert main(["create", "--owner", "Tommy", "--project", "Humanity Foundation", "--output", str(capsule)]) == 0

    code = main(["session", "import", str(tmp_path / "missing.txt"), "--capsule", str(capsule)])

    assert code == 1
