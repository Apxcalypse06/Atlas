import json
import zipfile
from pathlib import Path

import pytest

from pac.creator import CreateOptions, PacCreator
from pac.session import PacSessionImporter, SessionImportOptions
from pac.validator import PacValidator


def read_json(capsule: Path, path: str):
    with zipfile.ZipFile(capsule, "r") as archive:
        return json.loads(archive.read(path).decode("utf-8"))


def namelist(capsule: Path):
    with zipfile.ZipFile(capsule, "r") as archive:
        return set(archive.namelist())


def test_session_import_adds_file_index_memory_and_keeps_capsule_valid(tmp_path: Path):
    capsule = tmp_path / "session.pac.zip"
    source = tmp_path / "chat.txt"
    source.write_text("hello conversation", encoding="utf-8")

    PacCreator().create(CreateOptions(owner="Tommy", project="Humanity Foundation", output=capsule))

    result = PacSessionImporter().import_session(
        SessionImportOptions(source=source, capsule=capsule, label="Test chat")
    )

    assert result.valid_after_update
    assert PacValidator().validate(capsule).valid
    assert result.session_path in namelist(capsule)
    assert "sessions/index.json" in namelist(capsule)

    index = read_json(capsule, "sessions/index.json")
    assert len(index["sessions"]) == 1
    assert index["sessions"][0]["id"] == result.session_id
    assert index["sessions"][0]["label"] == "Test chat"
    assert index["sessions"][0]["sha256"]

    memory = read_json(capsule, "user/memory.json")
    assert any(result.session_id in item["text"] for item in memory["memories"])


def test_session_import_rejects_missing_source(tmp_path: Path):
    capsule = tmp_path / "session.pac.zip"
    PacCreator().create(CreateOptions(owner="Tommy", project="Humanity Foundation", output=capsule))

    with pytest.raises(FileNotFoundError):
        PacSessionImporter().import_session(
            SessionImportOptions(source=tmp_path / "missing.txt", capsule=capsule)
        )


def test_session_import_updates_manifest_timestamp(tmp_path: Path):
    capsule = tmp_path / "session.pac.zip"
    source = tmp_path / "chat.txt"
    source.write_text("hello", encoding="utf-8")

    PacCreator().create(CreateOptions(owner="Tommy", project="Humanity Foundation", output=capsule))
    before = read_json(capsule, "MANIFEST.json")["updated_at"]

    PacSessionImporter().import_session(SessionImportOptions(source=source, capsule=capsule))

    after = read_json(capsule, "MANIFEST.json")["updated_at"]
    assert after != before
