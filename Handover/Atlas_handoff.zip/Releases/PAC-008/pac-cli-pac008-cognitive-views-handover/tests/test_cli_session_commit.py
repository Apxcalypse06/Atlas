import json
import zipfile
from pathlib import Path

from pac.cli import main


def test_cli_session_commit(tmp_path: Path, capsys):
    cap = tmp_path / "cli-commit.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation to commit.", encoding="utf-8")
    assert main(["create", "--owner", "Tommy", "--project", "Atlas", "--output", str(cap)]) == 0
    assert main(["session", "import", str(src), "--capsule", str(cap), "--label", "Chat"]) == 0
    with zipfile.ZipFile(cap, "r") as z:
        sid = json.loads(z.read("sessions/index.json").decode())["sessions"][0]["id"]
    assert main(["session", "analyze", str(cap), "--session", sid]) == 0
    assert main(["session", "validate", str(cap), "--session", sid, "--validated-by", "Tommy"]) == 0
    assert main(["session", "select", str(cap), "--session", sid, "--selected-by", "Tommy"]) == 0

    code = main(["session", "commit", str(cap), "--session", sid, "--committed-by", "Tommy"])
    out = capsys.readouterr().out

    assert code == 0
    assert "Session memory committed:" in out
    assert "Committed candidates:" in out
    assert "Skipped candidates:" in out
    assert "Capsule valid: yes" in out


def test_cli_session_commit_without_selection_returns_1(tmp_path: Path):
    cap = tmp_path / "cli-commit.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation to commit.", encoding="utf-8")
    assert main(["create", "--owner", "Tommy", "--project", "Atlas", "--output", str(cap)]) == 0
    assert main(["session", "import", str(src), "--capsule", str(cap)]) == 0
    with zipfile.ZipFile(cap, "r") as z:
        sid = json.loads(z.read("sessions/index.json").decode())["sessions"][0]["id"]

    assert main(["session", "commit", str(cap), "--session", sid, "--committed-by", "Tommy"]) == 1
