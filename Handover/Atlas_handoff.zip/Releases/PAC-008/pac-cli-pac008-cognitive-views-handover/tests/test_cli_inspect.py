from pathlib import Path

from pac.cli import main


def test_cli_inspect_valid_capsule(tmp_path: Path, capsys):
    output = tmp_path / "cli-inspect.pac.zip"

    assert main(["create", "--owner", "Tommy", "--project", "Humanity Foundation", "--output", str(output)]) == 0
    assert main(["inspect", str(output)]) == 0

    captured = capsys.readouterr()
    assert "PAC Capsule" in captured.out
    assert "Project: Humanity Foundation" in captured.out
    assert "Validation: VALID" in captured.out


def test_cli_inspect_invalid_capsule_returns_1(tmp_path: Path):
    invalid = tmp_path / "invalid.txt"
    invalid.write_text("not a zip", encoding="utf-8")

    assert main(["inspect", str(invalid)]) == 1
