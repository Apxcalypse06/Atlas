import json
import zipfile
from pathlib import Path

import pytest

from pac.analyzer import PacSessionAnalyzer, SessionAnalyzeOptions
from pac.creator import CreateOptions, PacCreator
from pac.session import PacSessionImporter, SessionImportOptions
from pac.session_validator import PacSessionValidationPipeline, SessionValidateOptions
from pac.validator import PacValidator


def read_json(capsule: Path, path: str):
    with zipfile.ZipFile(capsule, "r") as z:
        return json.loads(z.read(path).decode())


def read_bytes(capsule: Path, path: str) -> bytes:
    with zipfile.ZipFile(capsule, "r") as z:
        return z.read(path)


def names(capsule: Path):
    with zipfile.ZipFile(capsule, "r") as z:
        return set(z.namelist())


def make_analyzed_capsule(tmp_path: Path):
    cap = tmp_path / "validation.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation for validation.", encoding="utf-8")
    PacCreator().create(CreateOptions(owner="Tommy", project="Atlas", output=cap))
    imported = PacSessionImporter().import_session(SessionImportOptions(source=src, capsule=cap, label="PAC-007.1 test"))
    PacSessionAnalyzer().analyze(SessionAnalyzeOptions(capsule=cap, session_id=imported.session_id))
    return cap, imported.session_id


def test_validate_session_creates_validation_artifact(tmp_path: Path):
    cap, sid = make_analyzed_capsule(tmp_path)
    result = PacSessionValidationPipeline().validate_session(
        SessionValidateOptions(capsule=cap, session_id=sid, validated_by="Tommy")
    )
    assert result.valid_after_update
    assert PacValidator().validate(cap).valid
    assert result.validation_path == f"sessions/validation/{sid}.validation.json"
    assert result.validation_path in names(cap)
    validation = read_json(cap, result.validation_path)
    assert validation == {
        "version": "0.1",
        "session_id": sid,
        "analysis_version": "0.1",
        "status": "reviewed",
        "validated_by": "Tommy",
        "validated_at": validation["validated_at"],
        "results": [],
    }


def test_validate_session_does_not_modify_source_artifacts_or_memory(tmp_path: Path):
    cap, sid = make_analyzed_capsule(tmp_path)
    session_path = read_json(cap, "sessions/index.json")["sessions"][0]["path"]
    analysis_path = f"sessions/analysis/{sid}.analysis.json"
    before_session = read_bytes(cap, session_path)
    before_analysis = read_bytes(cap, analysis_path)
    before_memory = read_bytes(cap, "user/memory.json")
    PacSessionValidationPipeline().validate_session(
        SessionValidateOptions(capsule=cap, session_id=sid, validated_by="Tommy")
    )
    assert read_bytes(cap, session_path) == before_session
    assert read_bytes(cap, analysis_path) == before_analysis
    assert read_bytes(cap, "user/memory.json") == before_memory


def test_validate_session_requires_existing_analysis(tmp_path: Path):
    cap = tmp_path / "validation.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation without analysis.", encoding="utf-8")
    PacCreator().create(CreateOptions(owner="Tommy", project="Atlas", output=cap))
    imported = PacSessionImporter().import_session(SessionImportOptions(source=src, capsule=cap))
    with pytest.raises(ValueError, match="analysis file missing"):
        PacSessionValidationPipeline().validate_session(
            SessionValidateOptions(capsule=cap, session_id=imported.session_id, validated_by="Tommy")
        )


def test_validate_session_rejects_empty_reviewer(tmp_path: Path):
    cap, sid = make_analyzed_capsule(tmp_path)
    with pytest.raises(ValueError, match="validated_by"):
        PacSessionValidationPipeline().validate_session(
            SessionValidateOptions(capsule=cap, session_id=sid, validated_by=" ")
        )
