import json
import zipfile
from pathlib import Path

from pac.cli import main


def read_memory(capsule: Path):
    with zipfile.ZipFile(capsule, "r") as archive:
        return json.loads(archive.read("user/memory.json").decode("utf-8"))


def test_cli_memory_add(tmp_path: Path, capsys):
    capsule = tmp_path / "cli-memory.pac.zip"

    assert main(["create", "--owner", "Tommy", "--project", "Humanity Foundation", "--output", str(capsule)]) == 0

    code = main([
        "memory",
        "add",
        str(capsule),
        "--type",
        "decision",
        "--text",
        "PAC-003 is DONE.",
    ])

    captured = capsys.readouterr()

    assert code == 0
    assert "Memory added:" in captured.out
    assert "Capsule valid: yes" in captured.out

    memory = read_memory(capsule)
    assert len(memory["memories"]) == 1
    assert memory["memories"][0]["type"] == "decision"


def test_cli_memory_add_invalid_type_returns_1(tmp_path: Path):
    capsule = tmp_path / "cli-memory.pac.zip"
    assert main(["create", "--owner", "Tommy", "--project", "Humanity Foundation", "--output", str(capsule)]) == 0

    code = main([
        "memory",
        "add",
        str(capsule),
        "--type",
        "bad",
        "--text",
        "x",
    ])

    assert code == 1
