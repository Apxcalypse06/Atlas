# PAC-007.3 Memory Commit Architecture

## Role

PAC-007.3 is the memory commit stage.

It sits after PAC-007.2 selection and before PAC-008 cognitive views and handover generation.

```text
Selection / Classification
  -> Memory Commit
  -> Cognitive Views & Handover
```

## Input

PAC-007.3 reads:

```text
sessions/selection/<session_id>.selection.json
```

## Outputs

PAC-007.3 writes selected candidates to:

```text
user/memory.json
projects/<project_id>/memory.json
shared/memory.json
```

## Invariant

An artifact never modifies its source artifact.

PAC-007.3 must not modify:

- source session files;
- analysis artifacts;
- validation artifacts;
- selection artifacts.

PAC-007.3 may update:

- memory files;
- `MANIFEST.json.updated_at`;
- `logs/changelog.md`.

## Boundary

PAC-007.3 does not decide continuity value.

It trusts the selection artifact and commits only candidates where:

```json
{
  "keep": true
}
```

Candidates with `keep=false`, missing `keep`, or non-true `keep` are ignored.

## Provenance

Every committed memory entry preserves:

- session id;
- selection path;
- selection version;
- analysis path;
- validation path;
- selected by / selected at;
- candidate index;
- candidate source.
