# pac session analyze

## Usage

```bash
pac session analyze project.pac.zip --session SES-...
```

## Purpose

Creates a proposed analysis artifact for an imported session.

## Output

`sessions/analysis/<session_id>.analysis.json`

PAC-006 does not modify official memory and does not decide what is true.
