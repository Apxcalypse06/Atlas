# pac session import

## Usage

```bash
pac session import chat.txt --capsule project.pac.zip
```

Optional label:

```bash
pac session import chat.txt --capsule project.pac.zip --label "Genesis discussion"
```

## Purpose

`pac session import` stores a user-provided conversation/session file inside an existing PAC capsule.

## Files updated

- `sessions/<session_id>.<ext>`
- `sessions/index.json`
- `user/memory.json`
- `logs/changelog.md`
- `MANIFEST.json.updated_at`

## Non-goals

PAC-005 does not analyze the conversation.

PAC-005 does not summarize the conversation.

PAC-005 does not extract decisions automatically.

PAC-005 only imports the source file and records that the import happened.
