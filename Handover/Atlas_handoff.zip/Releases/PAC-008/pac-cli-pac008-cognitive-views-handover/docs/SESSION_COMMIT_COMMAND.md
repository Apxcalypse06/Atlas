# pac session commit

## Usage

```bash
pac session commit project.pac.zip --session SES-... --committed-by Tommy
```

## Purpose

Commits selected PAC-007.2 candidates into memory domain files.

## Required input

```text
sessions/selection/<session_id>.selection.json
```

## Outputs

```text
user/memory.json
projects/<project_id>/memory.json
shared/memory.json
```

## Rules

- `keep=false` candidates are ignored.
- `keep=true, category=user` writes to `user/memory.json`.
- `keep=true, category=project` writes to `projects/<project_id>/memory.json`.
- `keep=true, category=shared` writes to `shared/memory.json`.
- Re-running the command against the same selection skips already committed candidates.

## CLI output

```text
Session memory committed: SES-...
Committed candidates: N
Skipped candidates: N
Memory: user/memory.json
Capsule valid: yes
```
