# PAC-007.2 Selection Architecture

## Role

PAC-007.2 is the knowledge selection and classification stage.

It sits after PAC-007.1 validation and before PAC-007.3 memory commit.

```text
Session
  -> Analysis
  -> Validation
  -> Selection / Classification
  -> Future memory commit
```

## Invariant

An artifact never modifies its source artifact.

PAC-007.2 reads:

- `sessions/analysis/<session_id>.analysis.json`;
- `sessions/validation/<session_id>.validation.json`.

PAC-007.2 writes:

- `sessions/selection/<session_id>.selection.json`.

PAC-007.2 may update:

- `MANIFEST.json.updated_at`;
- `logs/changelog.md`.

PAC-007.2 must not modify:

- source session files;
- analysis artifacts;
- validation artifacts;
- memory files.

## Classification domains

Selected candidates can target one of the future Atlas memory domains:

- `user`;
- `project`;
- `shared`.

Project candidates carry a `project_id`.

## Default classification

Deterministic defaults keep the implementation auditable:

- `decisions`, `tasks`, `risks`, `principles`, `releases` and `evidence` are selected as project knowledge unless an item explicitly sets another supported category;
- `questions` are ignored by default;
- item-level `keep`, `category` and `project_id` fields are honored when present.

These defaults produce a reviewable selection artifact. They do not imply memory commit.
