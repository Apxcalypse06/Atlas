# pac session handover

## Usage

```bash
pac session handover project.pac.zip --generated-by Tommy
```

## Purpose

Generate cognitive views and a current handover from committed memory.

## Required inputs

```text
user/memory.json
projects/<project_id>/memory.json
shared/memory.json
```

Missing memory domains are treated as empty.

## Outputs

```text
views/current/user_memory_view.json
views/current/project_memory_view.json
views/current/shared_memory_view.json
views/current/cognitive_summary.json
handovers/current.md
```

## Rules

- Read committed memory entries only.
- Preserve provenance in JSON views.
- Group project memory by project id.
- Do not modify source session, analysis, validation, selection, or memory files.
- Update `MANIFEST.json.updated_at`, `MANIFEST.json.latest_handover`, `MANIFEST.json.latest_cognitive_views`, and `logs/changelog.md`.

## CLI output

```text
Cognitive views generated
Memory entries: N
View: views/current/user_memory_view.json
View: views/current/project_memory_view.json
View: views/current/shared_memory_view.json
View: views/current/cognitive_summary.json
Handover: handovers/current.md
Capsule valid: yes
```
