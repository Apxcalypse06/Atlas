# PAC-004 Memory Architecture

## Pipeline

1. Validate capsule before update.
2. Create a structured memory entry.
3. Read all ZIP entries.
4. Update `user/memory.json`.
5. Update `logs/changelog.md`.
6. Update `MANIFEST.json` `updated_at`.
7. Rewrite the capsule atomically through a temporary ZIP.
8. Validate the capsule after update.

## Invariant

A successful `pac memory add` must leave the capsule valid.

## Safety

PAC-004 only supports explicit user-provided memories.

It does not perform automatic extraction from conversations.
