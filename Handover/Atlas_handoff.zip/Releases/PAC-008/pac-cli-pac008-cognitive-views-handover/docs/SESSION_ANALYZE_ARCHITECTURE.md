# PAC-006 Session Analyze Architecture

Pipeline:

1. Validate capsule before analysis.
2. Load `sessions/index.json`.
3. Resolve target session ID.
4. Read the raw session file.
5. Produce a deterministic proposed analysis artifact.
6. Store it under `sessions/analysis/`.
7. Update changelog and manifest timestamp.
8. Validate capsule after analysis.

Invariant: PAC-006 produces proposed knowledge only. Official memory is not modified.
