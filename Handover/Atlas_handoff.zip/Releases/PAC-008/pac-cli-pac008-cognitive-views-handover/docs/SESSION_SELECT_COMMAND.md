# pac session select

## Usage

```bash
pac session select project.pac.zip --session SES-... --selected-by Tommy
```

## Purpose

Creates a knowledge selection/classification artifact for a validated session analysis.

## Required inputs

```text
sessions/analysis/<session_id>.analysis.json
sessions/validation/<session_id>.validation.json
```

## Output

```text
sessions/selection/<session_id>.selection.json
```

## Candidate fields

Each candidate contains:

- `statement`;
- `keep`;
- `category`: `user`, `project`, `shared`, or `null` when ignored;
- `project_id`: set when the candidate is project-scoped;
- `reason`;
- `source`.

## Non-goals

`pac session select` does not commit to memory files and does not generate handovers.
