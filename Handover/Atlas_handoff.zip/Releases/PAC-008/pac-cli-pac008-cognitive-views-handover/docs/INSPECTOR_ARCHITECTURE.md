# PacInspector Architecture

Pipeline:

1. Open capsule read-only.
2. Reuse `PacValidator`.
3. Read `MANIFEST.json` when possible.
4. List files.
5. Compare files against PAC v0.2 required files.
6. Produce `InspectionReport`.

Invariant:

`pac inspect` is read-only.
