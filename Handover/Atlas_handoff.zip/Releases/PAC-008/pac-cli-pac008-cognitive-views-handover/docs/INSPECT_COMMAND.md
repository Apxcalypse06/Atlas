# pac inspect

## Usage

```bash
pac inspect capsule.pac.zip
```

## Purpose

`pac inspect` displays the state of a PAC capsule without extracting it manually.

It shows:

- project;
- owner;
- PAC version;
- capsule ID;
- entrypoint;
- validation status;
- required files and presence status.

## Exit codes

- `0`: capsule is readable and valid.
- `1`: capsule is invalid or unreadable.

## Read-only guarantee

`pac inspect` must not modify the capsule.

It opens the ZIP archive for reading and produces an inspection report.

## Non-goals

`pac inspect` does not modify the capsule.

`pac inspect` does not extract the capsule to disk.

`pac inspect` does not update memories, decisions or project state.
