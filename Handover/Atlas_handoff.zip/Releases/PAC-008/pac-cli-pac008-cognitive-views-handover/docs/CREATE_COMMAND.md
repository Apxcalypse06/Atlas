# pac create

## Usage

```bash
pac create --owner "Tommy" --project "Humanity Foundation" --output project.pac.zip
```

## Overwrite behavior

By default, `pac create` refuses to overwrite an existing file.

Use `--force` to overwrite.

## Output extension

The output path must end with `.pac.zip`.

## Status

Alpha. The generated capsule is minimal but valid PAC v0.2.
