# pac memory add

## Usage

```bash
pac memory add capsule.pac.zip --type decision --text "PAC-003 is DONE."
```

## Purpose

`pac memory add` adds a structured memory entry to an existing PAC capsule.

## Supported memory types

- `decision`
- `task`
- `note`
- `principle`
- `release`
- `risk`

## Behavior

The command updates:

- `user/memory.json`
- `logs/changelog.md`
- `MANIFEST.json` `updated_at`

The capsule is validated after the update.

## Non-goals

PAC-004 does not analyze a full conversation.

PAC-004 does not infer memories automatically.

PAC-004 does not merge capsules.
