# Session Handover Architecture

PAC-008 is a derived-artifact stage.

It consumes committed memory from PAC-007.3 and creates cognitive continuity views plus a handover.

## Artifact Flow

```text
user/memory.json
projects/<project_id>/memory.json
shared/memory.json
    -> views/current/*.json
    -> handovers/current.md
```

## Boundaries

PAC-008 does not change:

- source session files;
- analysis artifacts;
- validation artifacts;
- selection artifacts;
- memory domain files.

PAC-008 may change:

- generated view artifacts;
- generated handover artifacts;
- capsule manifest metadata;
- changelog.

## View Model

The generator produces:

- a user memory view;
- a project memory view grouped by project id;
- a shared memory view;
- a cognitive summary with counts and source paths.

Each JSON view includes generation metadata and source memory paths.
