# PAC-005 Session Import Architecture

PAC-005.1 makes session import atomic.

Pipeline:

1. Validate capsule before import.
2. Read source file and compute SHA-256.
3. Validate required internal files.
4. Prepare all changes in memory.
5. Write a temporary ZIP.
6. Verify temporary ZIP integrity.
7. Atomically replace the original capsule.
8. Validate capsule after import.

Invariant:

- successful import leaves the capsule valid;
- failed import must not partially modify the capsule.
