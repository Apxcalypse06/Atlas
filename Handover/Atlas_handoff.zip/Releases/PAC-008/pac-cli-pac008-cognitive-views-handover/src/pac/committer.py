from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from .validator import PacValidator


@dataclass(frozen=True)
class SessionCommitOptions:
    capsule: Path
    session_id: str
    committed_by: str
    force: bool = False


@dataclass(frozen=True)
class SessionCommitResult:
    capsule: Path
    session_id: str
    committed_count: int
    skipped_count: int
    memory_paths: tuple[str, ...]
    valid_after_update: bool


class PacMemoryCommitter:
    MEMORY_VERSION = "0.3"
    ALLOWED_CATEGORIES = {"user", "project", "shared"}

    def commit(self, options: SessionCommitOptions) -> SessionCommitResult:
        if not options.session_id.startswith("SES-"):
            raise ValueError("session_id must start with 'SES-'")
        if not options.committed_by.strip():
            raise ValueError("committed_by must not be empty")
        if not options.capsule.exists():
            raise FileNotFoundError(f"capsule not found: {options.capsule}")
        if not zipfile.is_zipfile(options.capsule):
            raise ValueError("capsule is not a readable ZIP archive")

        before = PacValidator().validate(options.capsule)
        if not before.valid and not options.force:
            raise ValueError("capsule is invalid before memory commit; use --force to override")

        now = datetime.now(timezone.utc).isoformat()
        committed_count, skipped_count, memory_paths = self._atomic_commit(
            options.capsule,
            options.session_id,
            options.committed_by.strip(),
            now,
        )
        after = PacValidator().validate(options.capsule)
        return SessionCommitResult(
            options.capsule,
            options.session_id,
            committed_count,
            skipped_count,
            tuple(memory_paths),
            after.valid,
        )

    def _atomic_commit(
        self,
        capsule: Path,
        session_id: str,
        committed_by: str,
        committed_at: str,
    ) -> tuple[int, int, list[str]]:
        try:
            with zipfile.ZipFile(capsule, "r") as archive:
                existing = {name: archive.read(name) for name in archive.namelist()}
        except zipfile.BadZipFile as exc:
            raise ValueError("capsule is corrupted or unreadable") from exc

        required = ["MANIFEST.json", "sessions/index.json", "logs/changelog.md"]
        missing = [name for name in required if name not in existing]
        if missing:
            raise ValueError("capsule is missing required internal files: " + ", ".join(missing))

        manifest = self._read_json(existing["MANIFEST.json"], "MANIFEST.json")
        index = self._read_json(existing["sessions/index.json"], "sessions/index.json")
        sessions = index.get("sessions")
        if not isinstance(sessions, list):
            raise ValueError("sessions/index.json field 'sessions' must be a list")
        if not any(session.get("id") == session_id for session in sessions):
            raise ValueError(f"session not found in sessions/index.json: {session_id}")

        selection_path = f"sessions/selection/{session_id}.selection.json"
        if selection_path not in existing:
            raise ValueError(f"selection file missing from capsule: {selection_path}")
        selection = self._read_json(existing[selection_path], selection_path)
        if selection.get("session_id") != session_id:
            raise ValueError("selection field 'session_id' does not match requested session")

        candidates = selection.get("candidates")
        if not isinstance(candidates, list):
            raise ValueError("selection field 'candidates' must be a list")

        committed_count = 0
        skipped_count = 0
        touched_paths: set[str] = set()
        updated = dict(existing)

        for index, candidate in enumerate(candidates):
            if not isinstance(candidate, dict):
                raise ValueError("selection candidates must be JSON objects")
            if candidate.get("keep") is not True:
                skipped_count += 1
                continue

            category = candidate.get("category")
            if category not in self.ALLOWED_CATEGORIES:
                raise ValueError("kept candidate category must be one of: project, shared, user")

            memory_path = self._memory_path(category, candidate)
            memory = self._read_memory(updated.get(memory_path), memory_path, category, candidate)
            memories = memory.setdefault("memories", [])
            if not isinstance(memories, list):
                raise ValueError(f"{memory_path} field 'memories' must be a list")

            source_key = self._source_key(selection_path, index, candidate)
            if self._already_committed(memories, source_key):
                skipped_count += 1
                touched_paths.add(memory_path)
                updated[memory_path] = json.dumps(memory, ensure_ascii=False, indent=2).encode("utf-8")
                continue

            memories.append(
                {
                    "id": "MEM-" + str(uuid4()),
                    "statement": self._statement(candidate),
                    "category": category,
                    "project_id": candidate.get("project_id") if category == "project" else None,
                    "reason": candidate.get("reason"),
                    "committed_by": committed_by,
                    "committed_at": committed_at,
                    "source": {
                        "session_id": session_id,
                        "selection_path": selection_path,
                        "selection_version": selection.get("version"),
                        "source_analysis_path": selection.get("source_analysis_path"),
                        "source_validation_path": selection.get("source_validation_path"),
                        "selected_by": selection.get("selected_by"),
                        "selected_at": selection.get("selected_at"),
                        "candidate_index": index,
                        "candidate_source": candidate.get("source"),
                        "source_key": source_key,
                    },
                }
            )
            committed_count += 1
            touched_paths.add(memory_path)
            updated[memory_path] = json.dumps(memory, ensure_ascii=False, indent=2).encode("utf-8")

        manifest["updated_at"] = committed_at
        changelog = existing["logs/changelog.md"].decode("utf-8")
        changelog += (
            f"\n## {committed_at}\n\n"
            f"- Committed {committed_count} selected memory candidate(s) from `{selection_path}`.\n"
        )

        updated["MANIFEST.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
        updated["logs/changelog.md"] = changelog.encode("utf-8")

        tmp = capsule.with_name(capsule.name + ".tmp")
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as archive:
                for name, content in updated.items():
                    archive.writestr(name, content)
            with zipfile.ZipFile(tmp, "r") as archive:
                bad = archive.testzip()
                if bad is not None:
                    raise ValueError(f"temporary ZIP failed integrity check at {bad}")
            tmp.replace(capsule)
        finally:
            if tmp.exists():
                tmp.unlink()

        return committed_count, skipped_count, sorted(touched_paths)

    def _read_json(self, raw: bytes, path: str) -> dict[str, Any]:
        try:
            data = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"{path} is invalid JSON: {exc}") from exc
        if not isinstance(data, dict):
            raise ValueError(f"{path} must contain a JSON object")
        return data

    def _read_memory(
        self,
        raw: bytes | None,
        path: str,
        category: str,
        candidate: dict[str, Any],
    ) -> dict[str, Any]:
        if raw is None:
            memory: dict[str, Any] = {
                "version": self.MEMORY_VERSION,
                "domain": category,
                "memories": [],
            }
        else:
            memory = self._read_json(raw, path)
            memory.setdefault("version", self.MEMORY_VERSION)
            memory.setdefault("domain", category)
            memory.setdefault("memories", [])

        if category == "project":
            memory.setdefault("project_id", candidate.get("project_id"))
        return memory

    def _memory_path(self, category: str, candidate: dict[str, Any]) -> str:
        if category == "user":
            return "user/memory.json"
        if category == "shared":
            return "shared/memory.json"

        project_id = candidate.get("project_id")
        if not isinstance(project_id, str) or not project_id.strip():
            raise ValueError("project memory candidate must contain project_id")
        safe_project_id = self._safe_project_id(project_id)
        return f"projects/{safe_project_id}/memory.json"

    def _safe_project_id(self, project_id: str) -> str:
        if project_id in {".", ".."} or "/" in project_id or "\\" in project_id:
            raise ValueError("project_id must not contain path separators")
        return project_id

    def _statement(self, candidate: dict[str, Any]) -> str:
        statement = candidate.get("statement")
        if not isinstance(statement, str) or not statement.strip():
            raise ValueError("kept candidate statement must not be empty")
        return statement.strip()

    def _source_key(self, selection_path: str, index: int, candidate: dict[str, Any]) -> str:
        source = candidate.get("source")
        if isinstance(source, dict):
            field = source.get("analysis_field")
            source_index = source.get("index")
            if isinstance(field, str) and isinstance(source_index, int):
                return f"{selection_path}#{field}[{source_index}]"
        return f"{selection_path}#candidate[{index}]"

    def _already_committed(self, memories: list[Any], source_key: str) -> bool:
        for memory in memories:
            if isinstance(memory, dict):
                source = memory.get("source")
                if isinstance(source, dict) and source.get("source_key") == source_key:
                    return True
        return False
