from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from .validator import PacValidator


@dataclass(frozen=True)
class SessionValidateOptions:
    capsule: Path
    session_id: str
    validated_by: str
    force: bool = False


@dataclass(frozen=True)
class SessionValidateResult:
    capsule: Path
    session_id: str
    validation_path: str
    valid_after_update: bool


class PacSessionValidationPipeline:
    VALIDATION_VERSION = "0.1"
    STATUS = "reviewed"

    def validate_session(self, options: SessionValidateOptions) -> SessionValidateResult:
        if not options.session_id.startswith("SES-"):
            raise ValueError("session_id must start with 'SES-'")
        if not options.validated_by.strip():
            raise ValueError("validated_by must not be empty")
        if not options.capsule.exists():
            raise FileNotFoundError(f"capsule not found: {options.capsule}")
        if not zipfile.is_zipfile(options.capsule):
            raise ValueError("capsule is not a readable ZIP archive")

        before = PacValidator().validate(options.capsule)
        if not before.valid and not options.force:
            raise ValueError("capsule is invalid before validation; use --force to override")

        now = datetime.now(timezone.utc).isoformat()
        validation_path = self._atomic_write_validation(
            options.capsule,
            options.session_id,
            options.validated_by.strip(),
            now,
        )
        after = PacValidator().validate(options.capsule)
        return SessionValidateResult(options.capsule, options.session_id, validation_path, after.valid)

    def _atomic_write_validation(self, capsule: Path, session_id: str, validated_by: str, validated_at: str) -> str:
        try:
            with zipfile.ZipFile(capsule, "r") as archive:
                existing = {name: archive.read(name) for name in archive.namelist()}
        except zipfile.BadZipFile as exc:
            raise ValueError("capsule is corrupted or unreadable") from exc

        missing = [n for n in ["MANIFEST.json", "sessions/index.json", "logs/changelog.md"] if n not in existing]
        if missing:
            raise ValueError("capsule is missing required internal files: " + ", ".join(missing))

        try:
            manifest = json.loads(existing["MANIFEST.json"].decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"MANIFEST.json is invalid JSON: {exc}") from exc
        try:
            index = json.loads(existing["sessions/index.json"].decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"sessions/index.json is invalid JSON: {exc}") from exc

        sessions = index.get("sessions")
        if not isinstance(sessions, list):
            raise ValueError("sessions/index.json field 'sessions' must be a list")
        if not any(s.get("id") == session_id for s in sessions):
            raise ValueError(f"session not found in sessions/index.json: {session_id}")

        analysis_path = f"sessions/analysis/{session_id}.analysis.json"
        if analysis_path not in existing:
            raise ValueError(f"analysis file missing from capsule: {analysis_path}")
        try:
            analysis = json.loads(existing[analysis_path].decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"{analysis_path} is invalid JSON: {exc}") from exc

        analysis_version = analysis.get("version")
        if not isinstance(analysis_version, str):
            raise ValueError("analysis field 'version' must be a string")
        if analysis.get("session_id") != session_id:
            raise ValueError("analysis field 'session_id' does not match requested session")

        validation_path = f"sessions/validation/{session_id}.validation.json"
        validation = {
            "version": self.VALIDATION_VERSION,
            "session_id": session_id,
            "analysis_version": analysis_version,
            "status": self.STATUS,
            "validated_by": validated_by,
            "validated_at": validated_at,
            "results": [],
        }

        manifest["updated_at"] = validated_at
        changelog = existing["logs/changelog.md"].decode("utf-8")
        changelog += f"\n## {validated_at}\n\n- Created validation `{validation_path}` for analysis `{analysis_path}`.\n"

        updated = dict(existing)
        updated[validation_path] = json.dumps(validation, ensure_ascii=False, indent=2).encode("utf-8")
        updated["MANIFEST.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
        updated["logs/changelog.md"] = changelog.encode("utf-8")

        tmp = capsule.with_name(capsule.name + ".tmp")
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as archive:
                for name, content in updated.items():
                    archive.writestr(name, content)
            with zipfile.ZipFile(tmp, "r") as archive:
                bad = archive.testzip()
                if bad is not None:
                    raise ValueError(f"temporary ZIP failed integrity check at {bad}")
            tmp.replace(capsule)
        finally:
            if tmp.exists():
                tmp.unlink()
        return validation_path
