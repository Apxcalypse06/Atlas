from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from .validator import PacValidator


ALLOWED_MEMORY_TYPES = {"decision", "task", "note", "principle", "release", "risk"}


@dataclass(frozen=True)
class MemoryAddOptions:
    capsule: Path
    memory_type: str
    text: str
    force: bool = False


@dataclass(frozen=True)
class MemoryAddResult:
    capsule: Path
    memory_id: str
    memory_type: str
    valid_after_update: bool


class PacMemoryManager:
    def add(self, options: MemoryAddOptions) -> MemoryAddResult:
        capsule = options.capsule

        if options.memory_type not in ALLOWED_MEMORY_TYPES:
            allowed = ", ".join(sorted(ALLOWED_MEMORY_TYPES))
            raise ValueError(f"memory type must be one of: {allowed}")

        if not options.text.strip():
            raise ValueError("memory text must not be empty")

        before = PacValidator().validate(capsule)
        if not before.valid and not options.force:
            raise ValueError("capsule is invalid before update; use --force to override")

        memory_id = "MEM-" + str(uuid4())
        now = datetime.now(timezone.utc).isoformat()

        memory_entry = {
            "id": memory_id,
            "type": options.memory_type,
            "text": options.text,
            "created_at": now,
            "source": "pac memory add",
        }

        self._update_zip(capsule, memory_entry, now)

        after = PacValidator().validate(capsule)

        return MemoryAddResult(
            capsule=capsule,
            memory_id=memory_id,
            memory_type=options.memory_type,
            valid_after_update=after.valid,
        )

    def _update_zip(self, capsule: Path, memory_entry: dict, now: str) -> None:
        with zipfile.ZipFile(capsule, "r") as archive:
            existing_files = {
                name: archive.read(name)
                for name in archive.namelist()
            }

        memory_path = "user/memory.json"
        changelog_path = "logs/changelog.md"
        manifest_path = "MANIFEST.json"

        memory_data = self._read_memory(existing_files.get(memory_path, b"{}"))
        memories = memory_data.setdefault("memories", [])
        if not isinstance(memories, list):
            raise ValueError("user/memory.json field 'memories' must be a list")

        memories.append(memory_entry)

        changelog = existing_files.get(changelog_path, b"# Changelog\n").decode("utf-8")
        changelog += (
            f"\n## {now}\n\n"
            f"- Added memory `{memory_entry['id']}` "
            f"of type `{memory_entry['type']}`.\n"
        )

        manifest = json.loads(existing_files[manifest_path].decode("utf-8"))
        manifest["updated_at"] = now

        existing_files[memory_path] = json.dumps(memory_data, ensure_ascii=False, indent=2).encode("utf-8")
        existing_files[changelog_path] = changelog.encode("utf-8")
        existing_files[manifest_path] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")

        temp_path = capsule.with_suffix(capsule.suffix + ".tmp")

        with zipfile.ZipFile(temp_path, "w", zipfile.ZIP_DEFLATED) as archive:
            for name, data in existing_files.items():
                archive.writestr(name, data)

        temp_path.replace(capsule)

    def _read_memory(self, raw: bytes) -> dict:
        try:
            data = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"user/memory.json is invalid JSON: {exc}") from exc

        if not isinstance(data, dict):
            raise ValueError("user/memory.json must contain a JSON object")

        data.setdefault("version", "0.2")
        data.setdefault("memories", [])

        return data
