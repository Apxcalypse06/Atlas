from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .validator import PacValidator


@dataclass(frozen=True)
class HandoverGenerateOptions:
    capsule: Path
    generated_by: str
    force: bool = False


@dataclass(frozen=True)
class HandoverGenerateResult:
    capsule: Path
    view_paths: tuple[str, ...]
    handover_path: str
    memory_count: int
    valid_after_update: bool


class PacCognitiveViewGenerator:
    VIEW_VERSION = "0.1"

    def generate(self, options: HandoverGenerateOptions) -> HandoverGenerateResult:
        if not options.generated_by.strip():
            raise ValueError("generated_by must not be empty")
        if not options.capsule.exists():
            raise FileNotFoundError(f"capsule not found: {options.capsule}")
        if not zipfile.is_zipfile(options.capsule):
            raise ValueError("capsule is not a readable ZIP archive")

        before = PacValidator().validate(options.capsule)
        if not before.valid and not options.force:
            raise ValueError("capsule is invalid before handover generation; use --force to override")

        generated_at = datetime.now(timezone.utc).isoformat()
        view_paths, handover_path, memory_count = self._atomic_generate(
            options.capsule,
            options.generated_by.strip(),
            generated_at,
        )
        after = PacValidator().validate(options.capsule)
        return HandoverGenerateResult(
            options.capsule,
            tuple(view_paths),
            handover_path,
            memory_count,
            after.valid,
        )

    def _atomic_generate(
        self,
        capsule: Path,
        generated_by: str,
        generated_at: str,
    ) -> tuple[list[str], str, int]:
        try:
            with zipfile.ZipFile(capsule, "r") as archive:
                existing = {name: archive.read(name) for name in archive.namelist()}
        except zipfile.BadZipFile as exc:
            raise ValueError("capsule is corrupted or unreadable") from exc

        required = ["MANIFEST.json", "logs/changelog.md"]
        missing = [name for name in required if name not in existing]
        if missing:
            raise ValueError("capsule is missing required internal files: " + ", ".join(missing))

        manifest = self._read_json(existing["MANIFEST.json"], "MANIFEST.json")
        memory_sources = self._memory_sources(existing)
        views = self._build_views(memory_sources, generated_by, generated_at)
        handover = self._render_handover(manifest, views, generated_by, generated_at)

        updated = dict(existing)
        view_paths = [
            "views/current/user_memory_view.json",
            "views/current/project_memory_view.json",
            "views/current/shared_memory_view.json",
            "views/current/cognitive_summary.json",
        ]
        updated[view_paths[0]] = self._json_bytes(views["user"])
        updated[view_paths[1]] = self._json_bytes(views["project"])
        updated[view_paths[2]] = self._json_bytes(views["shared"])
        updated[view_paths[3]] = self._json_bytes(views["summary"])

        handover_path = "handovers/current.md"
        updated[handover_path] = handover.encode("utf-8")

        manifest["updated_at"] = generated_at
        manifest["latest_handover"] = handover_path
        manifest["latest_cognitive_views"] = view_paths
        changelog = existing["logs/changelog.md"].decode("utf-8")
        changelog += (
            f"\n## {generated_at}\n\n"
            f"- Generated cognitive views and handover from {views['summary']['memory_count']} memory entry(s).\n"
        )
        updated["MANIFEST.json"] = self._json_bytes(manifest)
        updated["logs/changelog.md"] = changelog.encode("utf-8")

        tmp = capsule.with_name(capsule.name + ".tmp")
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as archive:
                for name, content in updated.items():
                    archive.writestr(name, content)
            with zipfile.ZipFile(tmp, "r") as archive:
                bad = archive.testzip()
                if bad is not None:
                    raise ValueError(f"temporary ZIP failed integrity check at {bad}")
            tmp.replace(capsule)
        finally:
            if tmp.exists():
                tmp.unlink()

        return view_paths, handover_path, views["summary"]["memory_count"]

    def _memory_sources(self, existing: dict[str, bytes]) -> dict[str, list[dict[str, Any]]]:
        sources: dict[str, list[dict[str, Any]]] = {
            "user": [],
            "project": [],
            "shared": [],
        }
        for path in sorted(existing):
            if path == "user/memory.json":
                memory = self._read_memory(existing[path], path)
                sources["user"].extend(self._entries(memory, path))
            elif path == "shared/memory.json":
                memory = self._read_memory(existing[path], path)
                sources["shared"].extend(self._entries(memory, path))
            elif path.startswith("projects/") and path.endswith("/memory.json"):
                memory = self._read_memory(existing[path], path)
                sources["project"].extend(self._entries(memory, path))
        return sources

    def _build_views(
        self,
        sources: dict[str, list[dict[str, Any]]],
        generated_by: str,
        generated_at: str,
    ) -> dict[str, dict[str, Any]]:
        user_entries = self._sort_entries(sources["user"])
        project_entries = self._sort_entries(sources["project"])
        shared_entries = self._sort_entries(sources["shared"])
        memory_count = len(user_entries) + len(project_entries) + len(shared_entries)

        metadata = {
            "version": self.VIEW_VERSION,
            "generated_by": generated_by,
            "generated_at": generated_at,
        }
        return {
            "user": {
                **metadata,
                "domain": "user",
                "memory_count": len(user_entries),
                "entries": user_entries,
            },
            "project": {
                **metadata,
                "domain": "project",
                "memory_count": len(project_entries),
                "projects": self._group_by_project(project_entries),
            },
            "shared": {
                **metadata,
                "domain": "shared",
                "memory_count": len(shared_entries),
                "entries": shared_entries,
            },
            "summary": {
                **metadata,
                "memory_count": memory_count,
                "domains": {
                    "user": len(user_entries),
                    "project": len(project_entries),
                    "shared": len(shared_entries),
                },
                "source_paths": sorted(
                    {entry["source_memory_path"] for entry in user_entries + project_entries + shared_entries}
                ),
            },
        }

    def _render_handover(
        self,
        manifest: dict[str, Any],
        views: dict[str, dict[str, Any]],
        generated_by: str,
        generated_at: str,
    ) -> str:
        project = manifest.get("project", "unknown")
        lines = [
            "# Cognitive Handover",
            "",
            "## Metadata",
            "",
            f"- Project: {project}",
            f"- Generated by: {generated_by}",
            f"- Generated at: {generated_at}",
            f"- Memory entries: {views['summary']['memory_count']}",
            "",
            "## Domain Counts",
            "",
            f"- User: {views['summary']['domains']['user']}",
            f"- Project: {views['summary']['domains']['project']}",
            f"- Shared: {views['summary']['domains']['shared']}",
            "",
            "## User Memory",
            "",
            *self._entry_lines(views["user"].get("entries", [])),
            "",
            "## Project Memory",
            "",
            *self._project_lines(views["project"].get("projects", [])),
            "",
            "## Shared Memory",
            "",
            *self._entry_lines(views["shared"].get("entries", [])),
            "",
            "## Generated Artifacts",
            "",
            "- views/current/user_memory_view.json",
            "- views/current/project_memory_view.json",
            "- views/current/shared_memory_view.json",
            "- views/current/cognitive_summary.json",
            "",
            "## Boundary",
            "",
            "This handover is generated from committed memory. It does not replace source session, analysis, validation, selection, or memory artifacts.",
            "",
        ]
        return "\n".join(lines)

    def _entry_lines(self, entries: list[dict[str, Any]]) -> list[str]:
        if not entries:
            return ["No entries."]
        return [f"- {entry['statement']}" for entry in entries]

    def _project_lines(self, projects: list[dict[str, Any]]) -> list[str]:
        if not projects:
            return ["No entries."]
        lines: list[str] = []
        for project in projects:
            lines.append(f"### {project['project_id']}")
            lines.append("")
            lines.extend(self._entry_lines(project["entries"]))
            lines.append("")
        return lines[:-1] if lines and lines[-1] == "" else lines

    def _read_memory(self, raw: bytes, path: str) -> dict[str, Any]:
        memory = self._read_json(raw, path)
        memories = memory.get("memories")
        if memories is None:
            memory["memories"] = []
        elif not isinstance(memories, list):
            raise ValueError(f"{path} field 'memories' must be a list")
        return memory

    def _entries(self, memory: dict[str, Any], path: str) -> list[dict[str, Any]]:
        entries: list[dict[str, Any]] = []
        for index, item in enumerate(memory.get("memories", [])):
            if not isinstance(item, dict):
                raise ValueError(f"{path} memory entries must be JSON objects")
            statement = item.get("statement")
            if not isinstance(statement, str) or not statement.strip():
                continue
            entries.append(
                {
                    "id": item.get("id"),
                    "statement": statement.strip(),
                    "category": item.get("category") or memory.get("domain"),
                    "project_id": item.get("project_id") or memory.get("project_id"),
                    "reason": item.get("reason"),
                    "committed_at": item.get("committed_at"),
                    "source_memory_path": path,
                    "source_index": index,
                    "provenance": item.get("source"),
                }
            )
        return entries

    def _group_by_project(self, entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
        grouped: dict[str, list[dict[str, Any]]] = {}
        for entry in entries:
            project_id = entry.get("project_id") or self._project_id_from_path(entry["source_memory_path"])
            grouped.setdefault(str(project_id), []).append(entry)
        return [
            {
                "project_id": project_id,
                "memory_count": len(project_entries),
                "entries": project_entries,
            }
            for project_id, project_entries in sorted(grouped.items())
        ]

    def _project_id_from_path(self, path: str) -> str:
        parts = path.split("/")
        return parts[1] if len(parts) >= 3 else "unknown"

    def _sort_entries(self, entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return sorted(entries, key=lambda entry: (str(entry.get("committed_at") or ""), entry["source_memory_path"], entry["source_index"]))

    def _read_json(self, raw: bytes, path: str) -> dict[str, Any]:
        try:
            data = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"{path} is invalid JSON: {exc}") from exc
        if not isinstance(data, dict):
            raise ValueError(f"{path} must contain a JSON object")
        return data

    def _json_bytes(self, data: dict[str, Any]) -> bytes:
        return json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
