from __future__ import annotations

import hashlib, json, mimetypes, zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from .validator import PacValidator


@dataclass(frozen=True)
class SessionImportOptions:
    source: Path
    capsule: Path
    label: str | None = None
    force: bool = False


@dataclass(frozen=True)
class SessionImportResult:
    capsule: Path
    session_id: str
    session_path: str
    memory_id: str
    valid_after_update: bool


class PacSessionImporter:
    def import_session(self, options: SessionImportOptions) -> SessionImportResult:
        if not options.source.exists():
            raise FileNotFoundError(f"session source not found: {options.source}")
        if not options.source.is_file():
            raise ValueError("session source must be a file")
        if not options.capsule.exists():
            raise FileNotFoundError(f"capsule not found: {options.capsule}")
        if not zipfile.is_zipfile(options.capsule):
            raise ValueError("capsule is not a readable ZIP archive")

        before = PacValidator().validate(options.capsule)
        if not before.valid and not options.force:
            raise ValueError("capsule is invalid before import; use --force to override")

        data = options.source.read_bytes()
        now = datetime.now(timezone.utc).isoformat()
        session_id = "SES-" + str(uuid4())
        memory_id = "MEM-" + str(uuid4())
        ext = options.source.suffix or ".txt"
        session_path = f"sessions/{session_id}{ext}"
        digest = hashlib.sha256(data).hexdigest()

        metadata = {
            "id": session_id,
            "label": options.label or options.source.name,
            "source_filename": options.source.name,
            "imported_at": now,
            "sha256": digest,
            "size_bytes": len(data),
            "mime_type": mimetypes.guess_type(options.source.name)[0] or "application/octet-stream",
            "path": session_path,
        }

        self._atomic_update(options.capsule, session_path, data, metadata, memory_id, now)
        after = PacValidator().validate(options.capsule)
        return SessionImportResult(options.capsule, session_id, session_path, memory_id, after.valid)

    def _atomic_update(self, capsule: Path, session_path: str, session_data: bytes, metadata: dict, memory_id: str, now: str) -> None:
        try:
            with zipfile.ZipFile(capsule, "r") as archive:
                existing = {name: archive.read(name) for name in archive.namelist()}
        except zipfile.BadZipFile as exc:
            raise ValueError("capsule is corrupted or unreadable") from exc

        missing = [p for p in ["MANIFEST.json", "user/memory.json", "logs/changelog.md"] if p not in existing]
        if missing:
            raise ValueError("capsule is missing required internal files: " + ", ".join(missing))

        try:
            manifest = json.loads(existing["MANIFEST.json"].decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"MANIFEST.json is invalid JSON: {exc}") from exc

        try:
            memory = json.loads(existing["user/memory.json"].decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"user/memory.json is invalid JSON: {exc}") from exc

        if not isinstance(memory, dict):
            raise ValueError("user/memory.json must contain a JSON object")
        memories = memory.setdefault("memories", [])
        if not isinstance(memories, list):
            raise ValueError("user/memory.json field 'memories' must be a list")

        if "sessions/index.json" in existing:
            try:
                index = json.loads(existing["sessions/index.json"].decode("utf-8"))
            except json.JSONDecodeError as exc:
                raise ValueError(f"sessions/index.json is invalid JSON: {exc}") from exc
        else:
            index = {"version": "0.1", "sessions": []}

        sessions = index.setdefault("sessions", [])
        if not isinstance(sessions, list):
            raise ValueError("sessions/index.json field 'sessions' must be a list")

        memory_entry = {
            "id": memory_id,
            "type": "note",
            "text": f"Imported session `{metadata['id']}` from `{metadata['source_filename']}` into `{session_path}`.",
            "created_at": now,
            "source": "pac session import",
        }

        manifest["updated_at"] = now
        sessions.append(metadata)
        memories.append(memory_entry)
        changelog = existing["logs/changelog.md"].decode("utf-8")
        changelog += f"\n## {now}\n\n- Imported session `{metadata['id']}` to `{session_path}`.\n"
        changelog += f"- Added memory `{memory_id}` for session import.\n"

        updated = dict(existing)
        updated[session_path] = session_data
        updated["sessions/index.json"] = json.dumps(index, ensure_ascii=False, indent=2).encode("utf-8")
        updated["user/memory.json"] = json.dumps(memory, ensure_ascii=False, indent=2).encode("utf-8")
        updated["MANIFEST.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
        updated["logs/changelog.md"] = changelog.encode("utf-8")

        tmp = capsule.with_name(capsule.name + ".tmp")
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as archive:
                for name, content in updated.items():
                    archive.writestr(name, content)
            with zipfile.ZipFile(tmp, "r") as archive:
                bad = archive.testzip()
                if bad is not None:
                    raise ValueError(f"temporary ZIP failed integrity check at {bad}")
            tmp.replace(capsule)
        finally:
            if tmp.exists(): tmp.unlink()
