from __future__ import annotations

import json
import zipfile
from pathlib import Path

from .error_codes import ErrorCode
from .manifest import PacManifest
from .report import ValidationReport
from .spec import REQUIRED_FILES_BY_VERSION


class PacValidator:
    SUPPORTED_VERSIONS = {"0.2"}
    LEGACY_START_FILE = "00_START_HERE.md"

    def validate(self, capsule_path: str | Path) -> ValidationReport:
        path = Path(capsule_path)
        report = ValidationReport()

        if not path.exists():
            report.add_error(ErrorCode.CAPSULE_NOT_FOUND, f"Capsule not found: {path}")
            return report

        if not zipfile.is_zipfile(path):
            report.add_error(ErrorCode.NOT_ZIP, "Archive is not a readable ZIP file")
            return report

        report.add_check("Archive readable")

        try:
            with zipfile.ZipFile(path, "r") as archive:
                names = set(archive.namelist())
                manifest = self._read_manifest(archive, names, report)
                if manifest is None:
                    return report

                self._validate_manifest_semantics(manifest, report)
                self._validate_version(manifest, report)

                if report.valid:
                    self._validate_entrypoint(names, manifest, report)
                    self._validate_required_files(names, manifest, report)

        except zipfile.BadZipFile:
            report.add_error(ErrorCode.ARCHIVE_CORRUPTED, "Archive is corrupted or unreadable")
        except Exception as exc:
            report.add_error(ErrorCode.UNEXPECTED_ERROR, f"Unexpected validation error: {exc}")

        return report

    def _read_manifest(self, archive: zipfile.ZipFile, names: set[str], report: ValidationReport) -> PacManifest | None:
        if "MANIFEST.json" not in names:
            report.add_error(ErrorCode.MANIFEST_MISSING, "MANIFEST.json missing")
            return None

        report.add_check("MANIFEST.json found")

        try:
            raw = archive.read("MANIFEST.json").decode("utf-8")
            data = json.loads(raw)
            report.add_check("Manifest is valid JSON")
        except json.JSONDecodeError as exc:
            report.add_error(ErrorCode.MANIFEST_INVALID_JSON, f"MANIFEST.json is invalid JSON: {exc}")
            return None

        try:
            return PacManifest.from_dict(data)
        except ValueError as exc:
            msg = str(exc)
            code = ErrorCode.MANIFEST_FIELD_MISSING if msg.startswith("Missing manifest fields") else ErrorCode.MANIFEST_FIELD_INVALID
            report.add_error(code, msg)
            return None

    def _validate_manifest_semantics(self, manifest: PacManifest, report: ValidationReport) -> None:
        semantic_errors = manifest.validate_semantics()
        for error in semantic_errors:
            report.add_error(ErrorCode.MANIFEST_FIELD_INVALID, error)

        if not semantic_errors:
            report.add_check("Manifest fields valid")

    def _validate_version(self, manifest: PacManifest, report: ValidationReport) -> None:
        if manifest.version not in self.SUPPORTED_VERSIONS:
            report.add_error(ErrorCode.VERSION_UNSUPPORTED, f"Unsupported PAC version: {manifest.version}")
        else:
            report.add_check(f"PAC version supported: {manifest.version}")

    def _validate_entrypoint(self, names: set[str], manifest: PacManifest, report: ValidationReport) -> None:
        if manifest.entrypoint in names:
            report.add_check(f"Entrypoint exists: {manifest.entrypoint}")
            return

        if manifest.entrypoint == "00_INDEX.md" and self.LEGACY_START_FILE in names:
            report.add_warning("Using legacy 00_START_HERE.md alias for 00_INDEX.md")
            return

        report.add_error(ErrorCode.ENTRYPOINT_MISSING, f"Entrypoint missing: {manifest.entrypoint}")

    def _validate_required_files(self, names: set[str], manifest: PacManifest, report: ValidationReport) -> None:
        required = REQUIRED_FILES_BY_VERSION.get(manifest.version)
        if required is None:
            report.add_error(ErrorCode.VERSION_UNSUPPORTED, f"No required file set for PAC version: {manifest.version}")
            return

        missing = sorted(required - names)

        if "00_INDEX.md" in missing and self.LEGACY_START_FILE in names:
            missing.remove("00_INDEX.md")
            report.add_warning("Using legacy 00_START_HERE.md alias for 00_INDEX.md")

        if missing:
            report.add_error(ErrorCode.REQUIRED_FILE_MISSING, "Missing required files: " + ", ".join(missing))
            return

        report.add_check("Required files present")
        report.add_check("Handover present")
