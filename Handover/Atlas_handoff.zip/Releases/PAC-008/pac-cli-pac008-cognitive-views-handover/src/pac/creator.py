from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from .error_codes import ErrorCode
from .spec import PAC_PROTOCOL, PAC_VERSION, REQUIRED_READ_ORDER_V02


@dataclass(frozen=True)
class CreateOptions:
    owner: str
    project: str
    output: Path
    force: bool = False


class PacCreator:
    def create(self, options: CreateOptions) -> Path:
        if not options.owner.strip():
            raise ValueError("owner must not be empty")

        if not options.project.strip():
            raise ValueError("project must not be empty")

        output = options.output

        if not str(output).endswith(".pac.zip"):
            raise ValueError("output must end with .pac.zip")

        if output.exists() and not options.force:
            raise FileExistsError(f"{ErrorCode.OUTPUT_EXISTS}: Output already exists. Use --force to overwrite.")

        now = datetime.now(timezone.utc).isoformat()
        capsule_id = "PAC-" + str(uuid4())

        manifest = {
            "format": "PAC",
            "protocol": PAC_PROTOCOL,
            "version": PAC_VERSION,
            "capsule_id": capsule_id,
            "owner": options.owner,
            "project": options.project,
            "created_at": now,
            "updated_at": now,
            "entrypoint": "00_INDEX.md",
            "required_read_order": REQUIRED_READ_ORDER_V02,
        }

        files = {
            "00_INDEX.md": self._index(options.project),
            "01_HANDOVER.md": self._handover(options.owner, options.project, capsule_id),
            "MANIFEST.json": json.dumps(manifest, ensure_ascii=False, indent=2),
            "security/consent_policy.md": self._consent_policy(),
            "user/profile.json": json.dumps({"preferred_name": options.owner, "languages": ["fr"]}, ensure_ascii=False, indent=2),
            "user/memory.json": json.dumps({"version": PAC_VERSION, "memories": []}, ensure_ascii=False, indent=2),
            "projects/state.md": f"# Project State\n\nProject: {options.project}\n\nStatus: Created.\n",
            "projects/decisions.md": "# Decisions\n\nNo decisions recorded yet.\n",
            "logs/changelog.md": f"# Changelog\n\n## {now}\n\nCapsule created.\n",
        }

        output.parent.mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
            for name, content in files.items():
                archive.writestr(name, content)

        return output

    def _index(self, project: str) -> str:
        return f"""# PAC Capsule Index

This is a PAC v0.2 capsule.

## Project

{project}

## Recommended read order

1. 00_INDEX.md
2. 01_HANDOVER.md
3. MANIFEST.json
4. security/consent_policy.md
5. user/profile.json
6. user/memory.json
7. projects/state.md
8. projects/decisions.md
9. logs/changelog.md
"""

    def _handover(self, owner: str, project: str, capsule_id: str) -> str:
        now = datetime.now(timezone.utc).isoformat()
        return f"""# HANDOVER

## Metadata

- Handover version: 0.2
- PAC version: 0.2
- Capsule ID: {capsule_id}
- Project: {project}
- Author: {owner}
- Previous assistant: none
- Date: {now}
- Confidence: medium

## Transfer Intent

This capsule was created as a starting point for continuing a project across conversations, assistants, or tools.

## Current State

The capsule has been created but no project work has been recorded yet.

## Work Completed

- Initial PAC capsule created.

## Decisions Made

No decisions recorded yet.

## Open Questions

No open questions recorded yet.

## Risks and Limits

This capsule is minimal.

## Recommended Next Step

Add project state, decisions, memories, and a richer handover.

## Do Not Lose

The capsule belongs to its owner. Do not transfer, retain, or train on its contents without explicit consent.
"""

    def _consent_policy(self) -> str:
        return """# Consent Policy

The capsule belongs to its owner.

Default rule:

Do not transfer, retain, analyze, or train on personal/project data without explicit user consent.
"""
