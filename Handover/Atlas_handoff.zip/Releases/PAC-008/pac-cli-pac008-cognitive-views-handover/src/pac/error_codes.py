try:
    from enum import StrEnum
except ImportError:  # Python 3.10 compatibility
    from enum import Enum

    class StrEnum(str, Enum):
        pass


class ErrorCode(StrEnum):
    CAPSULE_NOT_FOUND = "PAC001"
    NOT_ZIP = "PAC002"
    MANIFEST_MISSING = "PAC003"
    MANIFEST_INVALID_JSON = "PAC004"
    MANIFEST_FIELD_MISSING = "PAC005"
    MANIFEST_FIELD_INVALID = "PAC006"
    VERSION_UNSUPPORTED = "PAC007"
    REQUIRED_FILE_MISSING = "PAC008"
    ENTRYPOINT_MISSING = "PAC009"
    ARCHIVE_CORRUPTED = "PAC010"
    OUTPUT_EXISTS = "PAC031"
    UNEXPECTED_ERROR = "PAC999"
