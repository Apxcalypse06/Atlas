from __future__ import annotations

from dataclasses import dataclass, field
from .error_codes import ErrorCode


@dataclass(frozen=True)
class ValidationIssue:
    code: ErrorCode
    message: str


@dataclass
class ValidationReport:
    valid: bool = True
    checks: list[str] = field(default_factory=list)
    errors: list[ValidationIssue] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def add_check(self, message: str) -> None:
        self.checks.append(message)

    def add_error(self, code: ErrorCode, message: str) -> None:
        self.valid = False
        self.errors.append(ValidationIssue(code=code, message=message))

    def add_warning(self, message: str) -> None:
        self.warnings.append(message)

    def to_text(self) -> str:
        lines = ["PAC Validation Report", "=====================", ""]
        lines += [f"✓ {check}" for check in self.checks]
        lines += [f"⚠ {warning}" for warning in self.warnings]
        lines += [f"✗ {error.code}: {error.message}" for error in self.errors]
        lines += ["", f"Result: {'VALID' if self.valid else 'INVALID'}"]
        return "\n".join(lines)
