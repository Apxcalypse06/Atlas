from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .validator import PacValidator


@dataclass(frozen=True)
class SessionSelectOptions:
    capsule: Path
    session_id: str
    selected_by: str
    force: bool = False


@dataclass(frozen=True)
class SessionSelectResult:
    capsule: Path
    session_id: str
    selection_path: str
    selected_count: int
    ignored_count: int
    valid_after_update: bool


class PacKnowledgeSelector:
    SELECTION_VERSION = "0.1"
    STATUS = "classified"
    ITEM_FIELDS = ("decisions", "tasks", "risks", "questions", "principles", "releases", "evidence")
    PROJECT_FIELDS = {"decisions", "tasks", "risks", "principles", "releases", "evidence"}

    def select(self, options: SessionSelectOptions) -> SessionSelectResult:
        if not options.session_id.startswith("SES-"):
            raise ValueError("session_id must start with 'SES-'")
        if not options.selected_by.strip():
            raise ValueError("selected_by must not be empty")
        if not options.capsule.exists():
            raise FileNotFoundError(f"capsule not found: {options.capsule}")
        if not zipfile.is_zipfile(options.capsule):
            raise ValueError("capsule is not a readable ZIP archive")

        before = PacValidator().validate(options.capsule)
        if not before.valid and not options.force:
            raise ValueError("capsule is invalid before selection; use --force to override")

        now = datetime.now(timezone.utc).isoformat()
        selection_path, selected_count, ignored_count = self._atomic_write_selection(
            options.capsule,
            options.session_id,
            options.selected_by.strip(),
            now,
        )
        after = PacValidator().validate(options.capsule)
        return SessionSelectResult(
            options.capsule,
            options.session_id,
            selection_path,
            selected_count,
            ignored_count,
            after.valid,
        )

    def _atomic_write_selection(
        self,
        capsule: Path,
        session_id: str,
        selected_by: str,
        selected_at: str,
    ) -> tuple[str, int, int]:
        try:
            with zipfile.ZipFile(capsule, "r") as archive:
                existing = {name: archive.read(name) for name in archive.namelist()}
        except zipfile.BadZipFile as exc:
            raise ValueError("capsule is corrupted or unreadable") from exc

        missing = [n for n in ["MANIFEST.json", "sessions/index.json", "logs/changelog.md"] if n not in existing]
        if missing:
            raise ValueError("capsule is missing required internal files: " + ", ".join(missing))

        try:
            manifest = json.loads(existing["MANIFEST.json"].decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"MANIFEST.json is invalid JSON: {exc}") from exc
        try:
            index = json.loads(existing["sessions/index.json"].decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"sessions/index.json is invalid JSON: {exc}") from exc

        sessions = index.get("sessions")
        if not isinstance(sessions, list):
            raise ValueError("sessions/index.json field 'sessions' must be a list")
        if not any(s.get("id") == session_id for s in sessions):
            raise ValueError(f"session not found in sessions/index.json: {session_id}")

        analysis_path = f"sessions/analysis/{session_id}.analysis.json"
        validation_path = f"sessions/validation/{session_id}.validation.json"
        if analysis_path not in existing:
            raise ValueError(f"analysis file missing from capsule: {analysis_path}")
        if validation_path not in existing:
            raise ValueError(f"validation file missing from capsule: {validation_path}")

        try:
            analysis = json.loads(existing[analysis_path].decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"{analysis_path} is invalid JSON: {exc}") from exc
        try:
            validation = json.loads(existing[validation_path].decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"{validation_path} is invalid JSON: {exc}") from exc

        analysis_version = analysis.get("version")
        validation_version = validation.get("version")
        if not isinstance(analysis_version, str):
            raise ValueError("analysis field 'version' must be a string")
        if not isinstance(validation_version, str):
            raise ValueError("validation field 'version' must be a string")
        if analysis.get("session_id") != session_id:
            raise ValueError("analysis field 'session_id' does not match requested session")
        if validation.get("session_id") != session_id:
            raise ValueError("validation field 'session_id' does not match requested session")

        project_id = self._project_id(manifest)
        candidates = self._build_candidates(analysis, project_id)
        selected_count = sum(1 for candidate in candidates if candidate["keep"])
        ignored_count = len(candidates) - selected_count

        selection_path = f"sessions/selection/{session_id}.selection.json"
        selection = {
            "version": self.SELECTION_VERSION,
            "session_id": session_id,
            "analysis_version": analysis_version,
            "validation_version": validation_version,
            "status": self.STATUS,
            "selected_by": selected_by,
            "selected_at": selected_at,
            "source_analysis_path": analysis_path,
            "source_validation_path": validation_path,
            "candidates": candidates,
        }

        manifest["updated_at"] = selected_at
        changelog = existing["logs/changelog.md"].decode("utf-8")
        changelog += f"\n## {selected_at}\n\n- Created selection `{selection_path}` for validation `{validation_path}`.\n"

        updated = dict(existing)
        updated[selection_path] = json.dumps(selection, ensure_ascii=False, indent=2).encode("utf-8")
        updated["MANIFEST.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
        updated["logs/changelog.md"] = changelog.encode("utf-8")

        tmp = capsule.with_name(capsule.name + ".tmp")
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as archive:
                for name, content in updated.items():
                    archive.writestr(name, content)
            with zipfile.ZipFile(tmp, "r") as archive:
                bad = archive.testzip()
                if bad is not None:
                    raise ValueError(f"temporary ZIP failed integrity check at {bad}")
            tmp.replace(capsule)
        finally:
            if tmp.exists():
                tmp.unlink()
        return selection_path, selected_count, ignored_count

    def _build_candidates(self, analysis: dict[str, Any], default_project_id: str) -> list[dict[str, Any]]:
        candidates: list[dict[str, Any]] = []
        for field in self.ITEM_FIELDS:
            items = analysis.get(field, [])
            if items is None:
                continue
            if not isinstance(items, list):
                raise ValueError(f"analysis field '{field}' must be a list")
            for index, item in enumerate(items):
                candidates.append(self._classify_item(field, index, item, default_project_id))
        return candidates

    def _classify_item(self, field: str, index: int, item: Any, default_project_id: str) -> dict[str, Any]:
        statement = self._statement(item)
        explicit_category = self._string_field(item, "category")
        explicit_project = self._string_field(item, "project_id")
        explicit_keep = self._bool_field(item, "keep")

        category = explicit_category if explicit_category in {"user", "project", "shared"} else None
        keep = explicit_keep if explicit_keep is not None else field in self.PROJECT_FIELDS
        if keep and category is None:
            category = "project"
        if not keep:
            category = None

        candidate = {
            "statement": statement,
            "keep": keep,
            "category": category,
            "project_id": default_project_id if keep and category == "project" else None,
            "reason": self._reason(field, keep, category),
            "source": {
                "analysis_field": field,
                "index": index,
            },
        }
        if keep and category == "project" and explicit_project:
            candidate["project_id"] = explicit_project
        return candidate

    def _statement(self, item: Any) -> str:
        if isinstance(item, str):
            return item
        if isinstance(item, dict):
            for key in ("statement", "text", "summary", "description", "title"):
                value = item.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip()
            return json.dumps(item, ensure_ascii=False, sort_keys=True)
        return str(item)

    def _string_field(self, item: Any, key: str) -> str | None:
        if not isinstance(item, dict):
            return None
        value = item.get(key)
        return value.strip() if isinstance(value, str) and value.strip() else None

    def _bool_field(self, item: Any, key: str) -> bool | None:
        if not isinstance(item, dict):
            return None
        value = item.get(key)
        return value if isinstance(value, bool) else None

    def _reason(self, field: str, keep: bool, category: str | None) -> str:
        if not keep:
            return "Not selected for memory continuity at this stage"
        if category == "user":
            return "User-level information relevant to continuity"
        if category == "shared":
            return "Shared information relevant across projects"
        return f"{field[:-1].title()} relevant to project continuity"

    def _project_id(self, manifest: dict[str, Any]) -> str:
        project = manifest.get("project")
        return project.strip() if isinstance(project, str) and project.strip() else "unknown"
