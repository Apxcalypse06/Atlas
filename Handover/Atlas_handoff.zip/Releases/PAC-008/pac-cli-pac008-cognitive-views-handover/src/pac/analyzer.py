from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from .validator import PacValidator


@dataclass(frozen=True)
class SessionAnalyzeOptions:
    capsule: Path
    session_id: str
    force: bool = False


@dataclass(frozen=True)
class SessionAnalyzeResult:
    capsule: Path
    session_id: str
    analysis_path: str
    valid_after_update: bool


class PacSessionAnalyzer:
    ANALYSIS_VERSION = "0.1"

    def analyze(self, options: SessionAnalyzeOptions) -> SessionAnalyzeResult:
        if not options.session_id.startswith("SES-"):
            raise ValueError("session_id must start with 'SES-'")
        if not options.capsule.exists():
            raise FileNotFoundError(f"capsule not found: {options.capsule}")
        if not zipfile.is_zipfile(options.capsule):
            raise ValueError("capsule is not a readable ZIP archive")

        before = PacValidator().validate(options.capsule)
        if not before.valid and not options.force:
            raise ValueError("capsule is invalid before analysis; use --force to override")

        now = datetime.now(timezone.utc).isoformat()
        analysis_path = self._atomic_write_analysis(options.capsule, options.session_id, now)
        after = PacValidator().validate(options.capsule)
        return SessionAnalyzeResult(options.capsule, options.session_id, analysis_path, after.valid)

    def _atomic_write_analysis(self, capsule: Path, session_id: str, analyzed_at: str) -> str:
        try:
            with zipfile.ZipFile(capsule, "r") as archive:
                existing = {name: archive.read(name) for name in archive.namelist()}
        except zipfile.BadZipFile as exc:
            raise ValueError("capsule is corrupted or unreadable") from exc

        missing = [n for n in ["MANIFEST.json", "sessions/index.json", "logs/changelog.md"] if n not in existing]
        if missing:
            raise ValueError("capsule is missing required internal files: " + ", ".join(missing))

        try:
            manifest = json.loads(existing["MANIFEST.json"].decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"MANIFEST.json is invalid JSON: {exc}") from exc
        try:
            index = json.loads(existing["sessions/index.json"].decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"sessions/index.json is invalid JSON: {exc}") from exc

        sessions = index.get("sessions")
        if not isinstance(sessions, list):
            raise ValueError("sessions/index.json field 'sessions' must be a list")

        meta = next((s for s in sessions if s.get("id") == session_id), None)
        if meta is None:
            raise ValueError(f"session not found in sessions/index.json: {session_id}")
        session_path = meta.get("path")
        if not isinstance(session_path, str):
            raise ValueError("session metadata field 'path' must be a string")
        if session_path not in existing:
            raise ValueError(f"session file missing from capsule: {session_path}")

        raw_text = existing[session_path].decode("utf-8", errors="replace")
        summary = self._build_minimal_summary(raw_text)
        analysis_path = f"sessions/analysis/{session_id}.analysis.json"
        analysis = {
            "version": self.ANALYSIS_VERSION,
            "session_id": session_id,
            "status": "proposed",
            "created_at": analyzed_at,
            "source_path": session_path,
            "summary": summary,
            "decisions": [],
            "tasks": [],
            "risks": [],
            "questions": [],
            "principles": [],
            "releases": [],
            "evidence": [],
        }
        manifest["updated_at"] = analyzed_at
        changelog = existing["logs/changelog.md"].decode("utf-8")
        changelog += f"\n## {analyzed_at}\n\n- Created analysis `{analysis_path}` for session `{session_id}`.\n"
        updated = dict(existing)
        updated[analysis_path] = json.dumps(analysis, ensure_ascii=False, indent=2).encode("utf-8")
        updated["MANIFEST.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
        updated["logs/changelog.md"] = changelog.encode("utf-8")
        tmp = capsule.with_name(capsule.name + ".tmp")
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as archive:
                for name, content in updated.items():
                    archive.writestr(name, content)
            with zipfile.ZipFile(tmp, "r") as archive:
                bad = archive.testzip()
                if bad is not None:
                    raise ValueError(f"temporary ZIP failed integrity check at {bad}")
            tmp.replace(capsule)
        finally:
            if tmp.exists():
                tmp.unlink()
        return analysis_path

    def _build_minimal_summary(self, text: str) -> str:
        cleaned = " ".join(text.split())
        if not cleaned:
            return ""
        return cleaned if len(cleaned) <= 240 else cleaned[:239].rstrip() + "…"
