from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass
from pathlib import Path

from .manifest import PacManifest
from .spec import REQUIRED_FILES_BY_VERSION
from .validator import PacValidator


@dataclass(frozen=True)
class InspectionReport:
    capsule_path: Path
    manifest: PacManifest | None
    files: list[str]
    required_files: list[str]
    missing_files: list[str]
    validation_valid: bool
    validation_errors: list[str]

    def to_text(self) -> str:
        lines = [
            "PAC Capsule",
            "===========",
            "",
        ]

        if self.manifest is None:
            lines.append("Manifest: unavailable")
        else:
            lines.extend([
                f"Project: {self.manifest.project}",
                f"Owner: {self.manifest.owner}",
                f"Version: {self.manifest.version}",
                f"Capsule ID: {self.manifest.capsule_id}",
                f"Entrypoint: {self.manifest.entrypoint}",
            ])

        lines.extend([
            "",
            f"Validation: {'VALID' if self.validation_valid else 'INVALID'}",
            "",
            "Required files:",
        ])

        for file_name in self.required_files:
            mark = "✓" if file_name not in self.missing_files else "✗"
            lines.append(f"{mark} {file_name}")

        if self.validation_errors:
            lines.extend(["", "Errors:"])
            lines.extend(f"- {error}" for error in self.validation_errors)

        return "\n".join(lines)


class PacInspector:
    def inspect(self, capsule_path: str | Path) -> InspectionReport:
        path = Path(capsule_path)
        validation = PacValidator().validate(path)

        manifest: PacManifest | None = None
        files: list[str] = []
        required_files: list[str] = []
        missing_files: list[str] = []

        if path.exists() and zipfile.is_zipfile(path):
            with zipfile.ZipFile(path, "r") as archive:
                files = sorted(archive.namelist())

                if "MANIFEST.json" in files:
                    try:
                        raw = archive.read("MANIFEST.json").decode("utf-8")
                        manifest = PacManifest.from_dict(json.loads(raw))
                        required_files = sorted(REQUIRED_FILES_BY_VERSION.get(manifest.version, set()))
                        names = set(files)
                        missing_files = [item for item in required_files if item not in names]
                    except Exception:
                        manifest = None

        validation_errors = [
            f"{issue.code}: {issue.message}"
            for issue in validation.errors
        ]

        return InspectionReport(
            capsule_path=path,
            manifest=manifest,
            files=files,
            required_files=required_files,
            missing_files=missing_files,
            validation_valid=validation.valid,
            validation_errors=validation_errors,
        )
