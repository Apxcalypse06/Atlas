from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from .spec import PAC_PROTOCOL, PAC_VERSION, REQUIRED_READ_ORDER_V02


@dataclass(frozen=True)
class PacManifest:
    format: str
    version: str
    capsule_id: str
    owner: str
    project: str
    created_at: str
    updated_at: str
    entrypoint: str
    required_read_order: list[str]
    protocol: str

    REQUIRED_FIELDS = [
        "format",
        "protocol",
        "version",
        "capsule_id",
        "owner",
        "project",
        "created_at",
        "updated_at",
        "entrypoint",
        "required_read_order",
    ]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PacManifest":
        missing = [field for field in cls.REQUIRED_FIELDS if field not in data]
        if missing:
            raise ValueError(f"Missing manifest fields: {', '.join(missing)}")

        if not isinstance(data["required_read_order"], list):
            raise ValueError("Manifest field 'required_read_order' must be a list")

        for field_name in [
            "format",
            "protocol",
            "version",
            "capsule_id",
            "owner",
            "project",
            "created_at",
            "updated_at",
            "entrypoint",
        ]:
            if not isinstance(data[field_name], str):
                raise ValueError(f"Manifest field '{field_name}' must be a string")

        if not all(isinstance(item, str) for item in data["required_read_order"]):
            raise ValueError("Manifest field 'required_read_order' must contain only strings")

        return cls(
            format=data["format"],
            protocol=data["protocol"],
            version=data["version"],
            capsule_id=data["capsule_id"],
            owner=data["owner"],
            project=data["project"],
            created_at=data["created_at"],
            updated_at=data["updated_at"],
            entrypoint=data["entrypoint"],
            required_read_order=data["required_read_order"],
        )

    def validate_semantics(self) -> list[str]:
        errors: list[str] = []

        if self.format != "PAC":
            errors.append(f"format must be 'PAC', got '{self.format}'")

        if self.protocol != PAC_PROTOCOL:
            errors.append(f"protocol must be '{PAC_PROTOCOL}', got '{self.protocol}'")

        if self.version != PAC_VERSION:
            errors.append(f"version must be '{PAC_VERSION}', got '{self.version}'")

        if not self.capsule_id.startswith("PAC-"):
            errors.append("capsule_id must start with 'PAC-'")

        if not self.owner.strip():
            errors.append("owner must not be empty")

        if not self.project.strip():
            errors.append("project must not be empty")

        if not self.entrypoint.strip():
            errors.append("entrypoint must not be empty")

        if self.required_read_order != REQUIRED_READ_ORDER_V02:
            errors.append("required_read_order does not match PAC v0.2 required order")

        for field_name, value in [("created_at", self.created_at), ("updated_at", self.updated_at)]:
            try:
                datetime.fromisoformat(value.replace("Z", "+00:00"))
            except ValueError:
                errors.append(f"{field_name} must be ISO-8601 datetime")

        return errors
