PAC_VERSION = "0.2"
PAC_PROTOCOL = "Portable AI Collaboration Protocol"

REQUIRED_READ_ORDER_V02 = [
    "00_INDEX.md",
    "01_HANDOVER.md",
    "MANIFEST.json",
    "security/consent_policy.md",
    "user/profile.json",
    "user/memory.json",
    "projects/state.md",
    "projects/decisions.md",
    "logs/changelog.md",
]

REQUIRED_FILES_BY_VERSION = {
    PAC_VERSION: set(REQUIRED_READ_ORDER_V02),
}
