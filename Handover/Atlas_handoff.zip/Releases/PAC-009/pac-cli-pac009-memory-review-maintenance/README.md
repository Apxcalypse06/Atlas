# PAC CLI - PAC-009 Memory Review & Maintenance

Reference implementation for PAC v0.2.

Current alpha version: `0.9.0-alpha`.

## Scope

PAC-009 reviews and maintains committed memory.

It updates existing memory entries without deleting them and preserves maintenance history.

## Commands

```bash
pac session validate project.pac.zip --session SES-... --validated-by Tommy
pac session select project.pac.zip --session SES-... --selected-by Tommy
pac session commit project.pac.zip --session SES-... --committed-by Tommy
pac session handover project.pac.zip --generated-by Tommy
pac memory review project.pac.zip
pac memory update project.pac.zip --memory-id MEM-... --statement "..." --updated-by Tommy --reason "..."
pac memory deprecate project.pac.zip --memory-id MEM-... --deprecated-by Tommy --reason "..."
pac memory merge project.pac.zip --target-id MEM-... --source-id MEM-... --merged-by Tommy --reason "..."
```

## Input

```text
user/memory.json
projects/<project_id>/memory.json
shared/memory.json
```

## Maintenance Behavior

- lists active or deprecated memory entries;
- updates statements while recording previous statements;
- deprecates obsolete memory without physical deletion;
- merges duplicate memories by deprecating the source and annotating the target;
- updates capsule metadata and changelog.

## Source Artifact Boundary

PAC-009 does not modify source session pipeline artifacts:

- source session file: unchanged;
- analysis artifact: unchanged;
- validation artifact: unchanged;
- selection artifact: unchanged.

PAC-009 is allowed to update:

- memory domain files;
- `MANIFEST.json.updated_at`;
- `logs/changelog.md`.

## Non-goals

PAC-009 does not:

- decide KEEP / IGNORE;
- reclassify candidates;
- import or analyze conversations;
- physically delete memory entries;
- automatically regenerate PAC-008 views;
- require an LLM.

## Test

```bash
pip install -e .
pytest -q
```
