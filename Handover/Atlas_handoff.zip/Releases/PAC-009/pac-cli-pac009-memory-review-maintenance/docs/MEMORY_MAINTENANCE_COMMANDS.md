# Memory Maintenance Commands

## Review

```bash
pac memory review project.pac.zip
pac memory review project.pac.zip --include-deprecated
```

Lists memory entries from:

```text
user/memory.json
projects/<project_id>/memory.json
shared/memory.json
```

Deprecated entries are hidden unless `--include-deprecated` is used.

## Update

```bash
pac memory update project.pac.zip --memory-id MEM-... --statement "..." --updated-by Tommy --reason "..."
```

Updates a memory statement and appends `maintenance_history` with the previous statement and reason.

## Deprecate

```bash
pac memory deprecate project.pac.zip --memory-id MEM-... --deprecated-by Tommy --reason "..."
```

Marks a memory entry as deprecated without removing it.

## Merge

```bash
pac memory merge project.pac.zip --target-id MEM-a --source-id MEM-b --merged-by Tommy --reason "duplicate"
```

Keeps the target memory, records `merged_from`, and deprecates the source memory.

## Boundary

PAC-009 may update memory domain files, manifest metadata, and changelog.

PAC-009 does not edit source session, analysis, validation, or selection artifacts.
