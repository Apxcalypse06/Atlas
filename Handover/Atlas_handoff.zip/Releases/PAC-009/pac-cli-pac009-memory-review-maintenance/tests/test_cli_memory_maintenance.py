import json
import zipfile
from pathlib import Path

from pac.cli import main


def memory_ids(capsule: Path):
    with zipfile.ZipFile(capsule, "r") as z:
        memory = json.loads(z.read("user/memory.json").decode())
    return [entry["id"] for entry in memory["memories"]]


def test_cli_memory_review_update_deprecate(tmp_path: Path, capsys):
    cap = tmp_path / "cli-maintenance.pac.zip"
    assert main(["create", "--owner", "Tommy", "--project", "Atlas", "--output", str(cap)]) == 0
    assert main(["memory", "add", str(cap), "--type", "note", "--text", "Original memory"]) == 0
    memory_id = memory_ids(cap)[0]

    assert main(["memory", "review", str(cap)]) == 0
    review_out = capsys.readouterr().out
    assert "Memory entries: 1" in review_out
    assert memory_id in review_out

    assert main(
        [
            "memory",
            "update",
            str(cap),
            "--memory-id",
            memory_id,
            "--statement",
            "Updated memory",
            "--updated-by",
            "Tommy",
            "--reason",
            "Clarify",
        ]
    ) == 0
    update_out = capsys.readouterr().out
    assert "Memory updated:" in update_out
    assert "Capsule valid: yes" in update_out

    assert main(
        [
            "memory",
            "deprecate",
            str(cap),
            "--memory-id",
            memory_id,
            "--deprecated-by",
            "Tommy",
            "--reason",
            "Obsolete",
        ]
    ) == 0
    deprecate_out = capsys.readouterr().out
    assert "Memory deprecated:" in deprecate_out

    assert main(["memory", "review", str(cap)]) == 0
    hidden_out = capsys.readouterr().out
    assert "Memory entries: 0" in hidden_out

    assert main(["memory", "review", str(cap), "--include-deprecated"]) == 0
    all_out = capsys.readouterr().out
    assert "Memory entries: 1" in all_out
    assert "[deprecated]" in all_out


def test_cli_memory_merge(tmp_path: Path, capsys):
    cap = tmp_path / "cli-merge.pac.zip"
    assert main(["create", "--owner", "Tommy", "--project", "Atlas", "--output", str(cap)]) == 0
    assert main(["memory", "add", str(cap), "--type", "note", "--text", "First memory"]) == 0
    assert main(["memory", "add", str(cap), "--type", "note", "--text", "Duplicate memory"]) == 0
    first, second = memory_ids(cap)

    assert main(
        [
            "memory",
            "merge",
            str(cap),
            "--target-id",
            first,
            "--source-id",
            second,
            "--merged-by",
            "Tommy",
            "--reason",
            "Duplicate",
            "--statement",
            "Merged memory",
        ]
    ) == 0
    out = capsys.readouterr().out

    assert f"Memory merged: {second} -> {first}" in out
    assert "Capsule valid: yes" in out
