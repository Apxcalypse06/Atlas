import json
import zipfile
from pathlib import Path

import pytest

from pac.analyzer import PacSessionAnalyzer, SessionAnalyzeOptions
from pac.committer import PacMemoryCommitter, SessionCommitOptions
from pac.creator import CreateOptions, PacCreator
from pac.memory_maintenance import (
    MemoryDeprecateOptions,
    MemoryMergeOptions,
    MemoryReviewOptions,
    MemoryUpdateOptions,
    PacMemoryMaintenance,
)
from pac.selector import PacKnowledgeSelector, SessionSelectOptions
from pac.session import PacSessionImporter, SessionImportOptions
from pac.session_validator import PacSessionValidationPipeline, SessionValidateOptions
from pac.validator import PacValidator


def read_json(capsule: Path, path: str):
    with zipfile.ZipFile(capsule, "r") as z:
        return json.loads(z.read(path).decode())


def replace_json(capsule: Path, path: str, data):
    with zipfile.ZipFile(capsule, "r") as z:
        existing = {name: z.read(name) for name in z.namelist()}
    existing[path] = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
    tmp = capsule.with_name(capsule.name + ".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for name, content in existing.items():
            z.writestr(name, content)
    tmp.replace(capsule)


def make_committed_capsule(tmp_path: Path):
    cap = tmp_path / "maintenance.pac.zip"
    src = tmp_path / "chat.txt"
    src.write_text("Conversation for memory maintenance.", encoding="utf-8")
    PacCreator().create(CreateOptions(owner="Tommy", project="Atlas", output=cap))
    imported = PacSessionImporter().import_session(SessionImportOptions(source=src, capsule=cap, label="PAC-009 test"))
    PacSessionAnalyzer().analyze(SessionAnalyzeOptions(capsule=cap, session_id=imported.session_id))
    PacSessionValidationPipeline().validate_session(
        SessionValidateOptions(capsule=cap, session_id=imported.session_id, validated_by="Tommy")
    )
    PacKnowledgeSelector().select(SessionSelectOptions(capsule=cap, session_id=imported.session_id, selected_by="Tommy"))
    selection_path = f"sessions/selection/{imported.session_id}.selection.json"
    selection = read_json(cap, selection_path)
    selection["candidates"] = [
        {
            "statement": "Tommy prefers continuity-focused memory.",
            "keep": True,
            "category": "user",
            "project_id": None,
            "reason": "Stable user preference",
            "source": {"analysis_field": "evidence", "index": 0},
        },
        {
            "statement": "Atlas memory maintenance should preserve provenance.",
            "keep": True,
            "category": "project",
            "project_id": "Atlas",
            "reason": "Maintenance rule",
            "source": {"analysis_field": "principles", "index": 0},
        },
        {
            "statement": "Atlas memory maintenance preserves provenance.",
            "keep": True,
            "category": "project",
            "project_id": "Atlas",
            "reason": "Duplicate maintenance rule",
            "source": {"analysis_field": "principles", "index": 1},
        },
    ]
    replace_json(cap, selection_path, selection)
    PacMemoryCommitter().commit(SessionCommitOptions(capsule=cap, session_id=imported.session_id, committed_by="Tommy"))
    project_memory = read_json(cap, "projects/Atlas/memory.json")
    return cap, project_memory["memories"][0]["id"], project_memory["memories"][1]["id"]


def test_review_lists_active_memory_entries(tmp_path: Path):
    cap, _, _ = make_committed_capsule(tmp_path)

    result = PacMemoryMaintenance().review(MemoryReviewOptions(capsule=cap))

    assert len(result.entries) == 4
    assert {entry["memory_path"] for entry in result.entries} == {"projects/Atlas/memory.json", "user/memory.json"}


def test_update_memory_entry_keeps_history(tmp_path: Path):
    cap, memory_id, _ = make_committed_capsule(tmp_path)
    result = PacMemoryMaintenance().update(
        MemoryUpdateOptions(
            capsule=cap,
            memory_id=memory_id,
            statement="Atlas memory maintenance must preserve provenance.",
            updated_by="Tommy",
            reason="Clarify wording",
        )
    )

    assert result.valid_after_update
    assert result.action == "updated"
    memory = read_json(cap, "projects/Atlas/memory.json")["memories"][0]
    assert memory["statement"] == "Atlas memory maintenance must preserve provenance."
    assert memory["maintenance_history"][0]["action"] == "updated"
    assert PacValidator().validate(cap).valid


def test_deprecate_hides_entry_from_default_review(tmp_path: Path):
    cap, memory_id, _ = make_committed_capsule(tmp_path)
    PacMemoryMaintenance().deprecate(
        MemoryDeprecateOptions(
            capsule=cap,
            memory_id=memory_id,
            deprecated_by="Tommy",
            reason="No longer accurate",
        )
    )

    active = PacMemoryMaintenance().review(MemoryReviewOptions(capsule=cap))
    all_entries = PacMemoryMaintenance().review(MemoryReviewOptions(capsule=cap, include_deprecated=True))

    assert len(active.entries) == 3
    assert len(all_entries.entries) == 4
    deprecated = [entry for entry in all_entries.entries if entry["id"] == memory_id][0]
    assert deprecated["status"] == "deprecated"


def test_merge_deprecates_source_and_records_target_history(tmp_path: Path):
    cap, target_id, source_id = make_committed_capsule(tmp_path)
    result = PacMemoryMaintenance().merge(
        MemoryMergeOptions(
            capsule=cap,
            target_id=target_id,
            source_id=source_id,
            merged_by="Tommy",
            reason="Duplicate project memory",
            statement="Atlas memory maintenance should preserve provenance.",
        )
    )

    assert result.valid_after_update
    memory = read_json(cap, "projects/Atlas/memory.json")
    target = [entry for entry in memory["memories"] if entry["id"] == target_id][0]
    source = [entry for entry in memory["memories"] if entry["id"] == source_id][0]
    assert target["merged_from"][0]["memory_id"] == source_id
    assert source["status"] == "deprecated"
    assert source["maintenance_history"][0]["action"] == "merged_source"


def test_update_rejects_missing_memory_id(tmp_path: Path):
    cap, _, _ = make_committed_capsule(tmp_path)

    with pytest.raises(ValueError, match="memory not found"):
        PacMemoryMaintenance().update(
            MemoryUpdateOptions(
                capsule=cap,
                memory_id="MEM-missing",
                statement="Nope",
                updated_by="Tommy",
                reason="Test",
            )
        )
