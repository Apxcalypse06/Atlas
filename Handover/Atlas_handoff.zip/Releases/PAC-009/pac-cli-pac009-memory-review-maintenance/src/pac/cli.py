from __future__ import annotations

import argparse
import zipfile
from pathlib import Path

from .creator import CreateOptions, PacCreator
from .handover import HandoverGenerateOptions, PacCognitiveViewGenerator
from .inspector import PacInspector
from .memory import MemoryAddOptions, PacMemoryManager
from .memory_maintenance import (
    MemoryDeprecateOptions,
    MemoryMergeOptions,
    MemoryReviewOptions,
    MemoryUpdateOptions,
    PacMemoryMaintenance,
)
from .analyzer import PacSessionAnalyzer, SessionAnalyzeOptions
from .committer import PacMemoryCommitter, SessionCommitOptions
from .selector import PacKnowledgeSelector, SessionSelectOptions
from .session import PacSessionImporter, SessionImportOptions
from .session_validator import PacSessionValidationPipeline, SessionValidateOptions
from .validator import PacValidator


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="pac")
    subparsers = parser.add_subparsers(dest="command", required=True)

    create_parser = subparsers.add_parser("create", help="Create a PAC v0.2 capsule")
    create_parser.add_argument("--owner", required=True)
    create_parser.add_argument("--project", required=True)
    create_parser.add_argument("--output", required=True)
    create_parser.add_argument("--force", action="store_true", help="Overwrite output if it already exists")

    validate_parser = subparsers.add_parser("validate", help="Validate a PAC capsule")
    validate_parser.add_argument("capsule", help="Path to .pac.zip capsule")

    inspect_parser = subparsers.add_parser("inspect", help="Inspect a PAC capsule")
    inspect_parser.add_argument("capsule", help="Path to .pac.zip capsule")


    memory_parser = subparsers.add_parser("memory", help="Manage PAC capsule memory")
    memory_subparsers = memory_parser.add_subparsers(dest="memory_command", required=True)

    memory_add_parser = memory_subparsers.add_parser("add", help="Add a memory entry to a PAC capsule")
    memory_add_parser.add_argument("capsule", help="Path to .pac.zip capsule")
    memory_add_parser.add_argument("--type", required=True, help="Memory type: decision, task, note, principle, release, risk")
    memory_add_parser.add_argument("--text", required=True, help="Memory text")
    memory_add_parser.add_argument("--force", action="store_true", help="Allow update even if capsule is invalid before update")

    memory_review_parser = memory_subparsers.add_parser("review", help="List committed memory entries")
    memory_review_parser.add_argument("capsule", help="Path to .pac.zip capsule")
    memory_review_parser.add_argument("--include-deprecated", action="store_true", help="Include deprecated memory entries")

    memory_update_parser = memory_subparsers.add_parser("update", help="Update a memory entry statement")
    memory_update_parser.add_argument("capsule", help="Path to .pac.zip capsule")
    memory_update_parser.add_argument("--memory-id", required=True, help="Memory ID to update")
    memory_update_parser.add_argument("--statement", required=True, help="Replacement statement")
    memory_update_parser.add_argument("--updated-by", required=True, help="Reviewer name for the update")
    memory_update_parser.add_argument("--reason", required=True, help="Reason for the update")
    memory_update_parser.add_argument("--force", action="store_true", help="Allow update even if capsule is invalid before update")

    memory_deprecate_parser = memory_subparsers.add_parser("deprecate", help="Mark a memory entry as deprecated")
    memory_deprecate_parser.add_argument("capsule", help="Path to .pac.zip capsule")
    memory_deprecate_parser.add_argument("--memory-id", required=True, help="Memory ID to deprecate")
    memory_deprecate_parser.add_argument("--deprecated-by", required=True, help="Reviewer name for the deprecation")
    memory_deprecate_parser.add_argument("--reason", required=True, help="Reason for deprecation")
    memory_deprecate_parser.add_argument("--force", action="store_true", help="Allow deprecation even if capsule is invalid before update")

    memory_merge_parser = memory_subparsers.add_parser("merge", help="Merge a duplicate memory entry into a target entry")
    memory_merge_parser.add_argument("capsule", help="Path to .pac.zip capsule")
    memory_merge_parser.add_argument("--target-id", required=True, help="Memory ID to keep")
    memory_merge_parser.add_argument("--source-id", required=True, help="Memory ID to deprecate after merge")
    memory_merge_parser.add_argument("--merged-by", required=True, help="Reviewer name for the merge")
    memory_merge_parser.add_argument("--reason", required=True, help="Reason for merge")
    memory_merge_parser.add_argument("--statement", help="Optional replacement statement for the target memory")
    memory_merge_parser.add_argument("--force", action="store_true", help="Allow merge even if capsule is invalid before update")


    session_parser = subparsers.add_parser("session", help="Manage imported conversation/session files")
    session_subparsers = session_parser.add_subparsers(dest="session_command", required=True)

    session_import_parser = session_subparsers.add_parser("import", help="Import a conversation/session file into a PAC capsule")
    session_import_parser.add_argument("source", help="Path to conversation/session file")
    session_import_parser.add_argument("--capsule", required=True, help="Path to target .pac.zip capsule")
    session_import_parser.add_argument("--label", help="Optional human-readable label")
    session_import_parser.add_argument("--force", action="store_true", help="Allow import even if capsule is invalid before import")

    session_analyze_parser = session_subparsers.add_parser("analyze", help="Analyze an imported session and create a proposed analysis artifact")
    session_analyze_parser.add_argument("capsule", help="Path to .pac.zip capsule")
    session_analyze_parser.add_argument("--session", required=True, help="Session ID to analyze")
    session_analyze_parser.add_argument("--force", action="store_true", help="Allow analysis even if capsule is invalid before analysis")

    session_validate_parser = session_subparsers.add_parser("validate", help="Create a validation artifact for a proposed session analysis")
    session_validate_parser.add_argument("capsule", help="Path to .pac.zip capsule")
    session_validate_parser.add_argument("--session", required=True, help="Session ID to validate")
    session_validate_parser.add_argument("--validated-by", required=True, help="Reviewer name for the validation artifact")
    session_validate_parser.add_argument("--force", action="store_true", help="Allow validation even if capsule is invalid before validation")

    session_select_parser = session_subparsers.add_parser("select", help="Select and classify knowledge candidates from a validated session analysis")
    session_select_parser.add_argument("capsule", help="Path to .pac.zip capsule")
    session_select_parser.add_argument("--session", required=True, help="Session ID to select/classify")
    session_select_parser.add_argument("--selected-by", required=True, help="Reviewer name for the selection artifact")
    session_select_parser.add_argument("--force", action="store_true", help="Allow selection even if capsule is invalid before selection")

    session_commit_parser = session_subparsers.add_parser("commit", help="Commit selected knowledge candidates into memory domains")
    session_commit_parser.add_argument("capsule", help="Path to .pac.zip capsule")
    session_commit_parser.add_argument("--session", required=True, help="Session ID to commit")
    session_commit_parser.add_argument("--committed-by", required=True, help="Reviewer name for the memory commit")
    session_commit_parser.add_argument("--force", action="store_true", help="Allow commit even if capsule is invalid before commit")

    session_handover_parser = session_subparsers.add_parser("handover", help="Generate cognitive views and current handover from committed memory")
    session_handover_parser.add_argument("capsule", help="Path to .pac.zip capsule")
    session_handover_parser.add_argument("--generated-by", required=True, help="Reviewer name for generated cognitive views")
    session_handover_parser.add_argument("--force", action="store_true", help="Allow generation even if capsule is invalid before generation")

    args = parser.parse_args(argv)

    if args.command == "create":
        try:
            output = PacCreator().create(CreateOptions(owner=args.owner, project=args.project, output=Path(args.output), force=args.force))
        except (ValueError, FileExistsError) as exc:
            print(f"Error: {exc}")
            return 1
        print(f"Created PAC capsule: {output}")
        return 0

    if args.command == "validate":
        report = PacValidator().validate(args.capsule)
        print(report.to_text())
        return 0 if report.valid else 1

    if args.command == "inspect":
        report = PacInspector().inspect(args.capsule)
        print(report.to_text())
        return 0 if report.validation_valid else 1


    if args.command == "memory":
        if args.memory_command == "add":
            try:
                result = PacMemoryManager().add(
                    MemoryAddOptions(
                        capsule=Path(args.capsule),
                        memory_type=args.type,
                        text=args.text,
                        force=args.force,
                    )
                )
            except ValueError as exc:
                print(f"Error: {exc}")
                return 1

            print(f"Memory added: {result.memory_id}")
            print(f"Type: {result.memory_type}")
            print(f"Capsule valid: {'yes' if result.valid_after_update else 'no'}")
            return 0 if result.valid_after_update else 1

        if args.memory_command == "review":
            try:
                result = PacMemoryMaintenance().review(
                    MemoryReviewOptions(
                        capsule=Path(args.capsule),
                        include_deprecated=args.include_deprecated,
                    )
                )
            except (ValueError, FileNotFoundError, zipfile.BadZipFile) as exc:
                print(f"Error: {exc}")
                return 1
            print(f"Memory entries: {len(result.entries)}")
            for entry in result.entries:
                print(f"{entry.get('id')} [{entry.get('status')}] {entry.get('memory_path')} :: {entry.get('statement')}")
            return 0

        if args.memory_command == "update":
            try:
                result = PacMemoryMaintenance().update(
                    MemoryUpdateOptions(
                        capsule=Path(args.capsule),
                        memory_id=args.memory_id,
                        statement=args.statement,
                        updated_by=args.updated_by,
                        reason=args.reason,
                        force=args.force,
                    )
                )
            except (ValueError, FileNotFoundError, zipfile.BadZipFile) as exc:
                print(f"Error: {exc}")
                return 1
            print(f"Memory updated: {result.memory_id}")
            print(f"Memory: {result.memory_path}")
            print(f"Capsule valid: {'yes' if result.valid_after_update else 'no'}")
            return 0 if result.valid_after_update else 1

        if args.memory_command == "deprecate":
            try:
                result = PacMemoryMaintenance().deprecate(
                    MemoryDeprecateOptions(
                        capsule=Path(args.capsule),
                        memory_id=args.memory_id,
                        deprecated_by=args.deprecated_by,
                        reason=args.reason,
                        force=args.force,
                    )
                )
            except (ValueError, FileNotFoundError, zipfile.BadZipFile) as exc:
                print(f"Error: {exc}")
                return 1
            print(f"Memory deprecated: {result.memory_id}")
            print(f"Memory: {result.memory_path}")
            print(f"Capsule valid: {'yes' if result.valid_after_update else 'no'}")
            return 0 if result.valid_after_update else 1

        if args.memory_command == "merge":
            try:
                result = PacMemoryMaintenance().merge(
                    MemoryMergeOptions(
                        capsule=Path(args.capsule),
                        target_id=args.target_id,
                        source_id=args.source_id,
                        merged_by=args.merged_by,
                        reason=args.reason,
                        statement=args.statement,
                        force=args.force,
                    )
                )
            except (ValueError, FileNotFoundError, zipfile.BadZipFile) as exc:
                print(f"Error: {exc}")
                return 1
            print(f"Memory merged: {args.source_id} -> {result.memory_id}")
            print(f"Memory: {result.memory_path}")
            print(f"Capsule valid: {'yes' if result.valid_after_update else 'no'}")
            return 0 if result.valid_after_update else 1


    if args.command == "session":
        if args.session_command == "import":
            try:
                result = PacSessionImporter().import_session(
                    SessionImportOptions(
                        source=Path(args.source),
                        capsule=Path(args.capsule),
                        label=args.label,
                        force=args.force,
                    )
                )
            except (ValueError, FileNotFoundError, KeyError, zipfile.BadZipFile) as exc:
                print(f"Error: {exc}")
                return 1

            print(f"Session imported: {result.session_id}")
            print(f"Path: {result.session_path}")
            print(f"Memory added: {result.memory_id}")
            print(f"Capsule valid: {'yes' if result.valid_after_update else 'no'}")
            return 0 if result.valid_after_update else 1

        if args.session_command == "analyze":
            try:
                result = PacSessionAnalyzer().analyze(
                    SessionAnalyzeOptions(
                        capsule=Path(args.capsule),
                        session_id=args.session,
                        force=args.force,
                    )
                )
            except (ValueError, FileNotFoundError, KeyError, zipfile.BadZipFile) as exc:
                print(f"Error: {exc}")
                return 1
            print(f"Session analyzed: {result.session_id}")
            print(f"Analysis: {result.analysis_path}")
            print(f"Capsule valid: {'yes' if result.valid_after_update else 'no'}")
            return 0 if result.valid_after_update else 1

        if args.session_command == "validate":
            try:
                result = PacSessionValidationPipeline().validate_session(
                    SessionValidateOptions(
                        capsule=Path(args.capsule),
                        session_id=args.session,
                        validated_by=args.validated_by,
                        force=args.force,
                    )
                )
            except (ValueError, FileNotFoundError, KeyError, zipfile.BadZipFile) as exc:
                print(f"Error: {exc}")
                return 1
            print(f"Session validation created: {result.session_id}")
            print(f"Validation: {result.validation_path}")
            print(f"Capsule valid: {'yes' if result.valid_after_update else 'no'}")
            return 0 if result.valid_after_update else 1

        if args.session_command == "select":
            try:
                result = PacKnowledgeSelector().select(
                    SessionSelectOptions(
                        capsule=Path(args.capsule),
                        session_id=args.session,
                        selected_by=args.selected_by,
                        force=args.force,
                    )
                )
            except (ValueError, FileNotFoundError, KeyError, zipfile.BadZipFile) as exc:
                print(f"Error: {exc}")
                return 1
            print(f"Session selection created: {result.session_id}")
            print(f"Selection: {result.selection_path}")
            print(f"Selected candidates: {result.selected_count}")
            print(f"Ignored candidates: {result.ignored_count}")
            print(f"Capsule valid: {'yes' if result.valid_after_update else 'no'}")
            return 0 if result.valid_after_update else 1

        if args.session_command == "commit":
            try:
                result = PacMemoryCommitter().commit(
                    SessionCommitOptions(
                        capsule=Path(args.capsule),
                        session_id=args.session,
                        committed_by=args.committed_by,
                        force=args.force,
                    )
                )
            except (ValueError, FileNotFoundError, KeyError, zipfile.BadZipFile) as exc:
                print(f"Error: {exc}")
                return 1
            print(f"Session memory committed: {result.session_id}")
            print(f"Committed candidates: {result.committed_count}")
            print(f"Skipped candidates: {result.skipped_count}")
            for memory_path in result.memory_paths:
                print(f"Memory: {memory_path}")
            print(f"Capsule valid: {'yes' if result.valid_after_update else 'no'}")
            return 0 if result.valid_after_update else 1

        if args.session_command == "handover":
            try:
                result = PacCognitiveViewGenerator().generate(
                    HandoverGenerateOptions(
                        capsule=Path(args.capsule),
                        generated_by=args.generated_by,
                        force=args.force,
                    )
                )
            except (ValueError, FileNotFoundError, KeyError, zipfile.BadZipFile) as exc:
                print(f"Error: {exc}")
                return 1
            print("Cognitive views generated")
            print(f"Memory entries: {result.memory_count}")
            for view_path in result.view_paths:
                print(f"View: {view_path}")
            print(f"Handover: {result.handover_path}")
            print(f"Capsule valid: {'yes' if result.valid_after_update else 'no'}")
            return 0 if result.valid_after_update else 1

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
