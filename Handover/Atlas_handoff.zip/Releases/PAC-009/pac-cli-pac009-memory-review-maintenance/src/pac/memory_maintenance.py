from __future__ import annotations

import json
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .validator import PacValidator


@dataclass(frozen=True)
class MemoryReviewOptions:
    capsule: Path
    include_deprecated: bool = False


@dataclass(frozen=True)
class MemoryUpdateOptions:
    capsule: Path
    memory_id: str
    statement: str
    updated_by: str
    reason: str
    force: bool = False


@dataclass(frozen=True)
class MemoryDeprecateOptions:
    capsule: Path
    memory_id: str
    deprecated_by: str
    reason: str
    force: bool = False


@dataclass(frozen=True)
class MemoryMergeOptions:
    capsule: Path
    target_id: str
    source_id: str
    merged_by: str
    reason: str
    statement: str | None = None
    force: bool = False


@dataclass(frozen=True)
class MemoryReviewResult:
    entries: tuple[dict[str, Any], ...]


@dataclass(frozen=True)
class MemoryMaintenanceResult:
    capsule: Path
    memory_id: str
    memory_path: str
    action: str
    valid_after_update: bool


class PacMemoryMaintenance:
    def review(self, options: MemoryReviewOptions) -> MemoryReviewResult:
        if not options.capsule.exists():
            raise FileNotFoundError(f"capsule not found: {options.capsule}")
        if not zipfile.is_zipfile(options.capsule):
            raise ValueError("capsule is not a readable ZIP archive")

        with zipfile.ZipFile(options.capsule, "r") as archive:
            existing = {name: archive.read(name) for name in archive.namelist()}

        entries = []
        for memory_path, memory in self._memory_documents(existing):
            for index, entry in enumerate(self._entries(memory, memory_path)):
                if not options.include_deprecated and entry.get("status") == "deprecated":
                    continue
                entries.append(self._summary(entry, memory_path, index))
        return MemoryReviewResult(tuple(sorted(entries, key=lambda item: (item["memory_path"], item["index"]))))

    def update(self, options: MemoryUpdateOptions) -> MemoryMaintenanceResult:
        if not options.memory_id.strip():
            raise ValueError("memory_id must not be empty")
        if not options.statement.strip():
            raise ValueError("statement must not be empty")
        if not options.updated_by.strip():
            raise ValueError("updated_by must not be empty")
        if not options.reason.strip():
            raise ValueError("reason must not be empty")

        now = datetime.now(timezone.utc).isoformat()
        return self._atomic_update(
            options.capsule,
            options.force,
            lambda existing: self._update_entry(
                existing,
                options.memory_id.strip(),
                options.statement.strip(),
                options.updated_by.strip(),
                options.reason.strip(),
                now,
            ),
        )

    def deprecate(self, options: MemoryDeprecateOptions) -> MemoryMaintenanceResult:
        if not options.memory_id.strip():
            raise ValueError("memory_id must not be empty")
        if not options.deprecated_by.strip():
            raise ValueError("deprecated_by must not be empty")
        if not options.reason.strip():
            raise ValueError("reason must not be empty")

        now = datetime.now(timezone.utc).isoformat()
        return self._atomic_update(
            options.capsule,
            options.force,
            lambda existing: self._deprecate_entry(
                existing,
                options.memory_id.strip(),
                options.deprecated_by.strip(),
                options.reason.strip(),
                now,
                action="deprecated",
            ),
        )

    def merge(self, options: MemoryMergeOptions) -> MemoryMaintenanceResult:
        if not options.target_id.strip():
            raise ValueError("target_id must not be empty")
        if not options.source_id.strip():
            raise ValueError("source_id must not be empty")
        if options.target_id.strip() == options.source_id.strip():
            raise ValueError("target_id and source_id must be different")
        if not options.merged_by.strip():
            raise ValueError("merged_by must not be empty")
        if not options.reason.strip():
            raise ValueError("reason must not be empty")

        now = datetime.now(timezone.utc).isoformat()
        return self._atomic_update(
            options.capsule,
            options.force,
            lambda existing: self._merge_entries(
                existing,
                options.target_id.strip(),
                options.source_id.strip(),
                options.merged_by.strip(),
                options.reason.strip(),
                options.statement.strip() if options.statement and options.statement.strip() else None,
                now,
            ),
        )

    def _atomic_update(self, capsule: Path, force: bool, change: Any) -> MemoryMaintenanceResult:
        if not capsule.exists():
            raise FileNotFoundError(f"capsule not found: {capsule}")
        if not zipfile.is_zipfile(capsule):
            raise ValueError("capsule is not a readable ZIP archive")

        before = PacValidator().validate(capsule)
        if not before.valid and not force:
            raise ValueError("capsule is invalid before memory maintenance; use --force to override")

        with zipfile.ZipFile(capsule, "r") as archive:
            existing = {name: archive.read(name) for name in archive.namelist()}

        if "MANIFEST.json" not in existing or "logs/changelog.md" not in existing:
            raise ValueError("capsule is missing required internal files: MANIFEST.json, logs/changelog.md")

        result, updated_paths, now, changelog_line = change(existing)
        manifest = self._read_json(existing["MANIFEST.json"], "MANIFEST.json")
        manifest["updated_at"] = now
        changelog = existing["logs/changelog.md"].decode("utf-8")
        changelog += f"\n## {now}\n\n- {changelog_line}\n"
        existing["MANIFEST.json"] = self._json_bytes(manifest)
        existing["logs/changelog.md"] = changelog.encode("utf-8")

        tmp = capsule.with_name(capsule.name + ".tmp")
        try:
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as archive:
                for name, content in existing.items():
                    archive.writestr(name, content)
            with zipfile.ZipFile(tmp, "r") as archive:
                bad = archive.testzip()
                if bad is not None:
                    raise ValueError(f"temporary ZIP failed integrity check at {bad}")
            tmp.replace(capsule)
        finally:
            if tmp.exists():
                tmp.unlink()

        after = PacValidator().validate(capsule)
        return MemoryMaintenanceResult(capsule, result["memory_id"], result["memory_path"], result["action"], after.valid)

    def _update_entry(
        self,
        existing: dict[str, bytes],
        memory_id: str,
        statement: str,
        updated_by: str,
        reason: str,
        now: str,
    ) -> tuple[dict[str, str], set[str], str, str]:
        memory_path, memory, entry = self._find_entry(existing, memory_id)
        history = entry.setdefault("maintenance_history", [])
        if not isinstance(history, list):
            raise ValueError("maintenance_history must be a list")
        previous_statement = self._statement(entry)
        self._set_statement(entry, statement)
        entry["updated_by"] = updated_by
        entry["updated_at"] = now
        history.append(
            {
                "action": "updated",
                "updated_by": updated_by,
                "updated_at": now,
                "reason": reason,
                "previous_statement": previous_statement,
            }
        )
        existing[memory_path] = self._json_bytes(memory)
        return (
            {"memory_id": memory_id, "memory_path": memory_path, "action": "updated"},
            {memory_path},
            now,
            f"Updated memory `{memory_id}` in `{memory_path}`.",
        )

    def _deprecate_entry(
        self,
        existing: dict[str, bytes],
        memory_id: str,
        deprecated_by: str,
        reason: str,
        now: str,
        action: str,
    ) -> tuple[dict[str, str], set[str], str, str]:
        memory_path, memory, entry = self._find_entry(existing, memory_id)
        history = entry.setdefault("maintenance_history", [])
        if not isinstance(history, list):
            raise ValueError("maintenance_history must be a list")
        entry["status"] = "deprecated"
        entry["deprecated_by"] = deprecated_by
        entry["deprecated_at"] = now
        entry["deprecation_reason"] = reason
        history.append(
            {
                "action": action,
                "deprecated_by": deprecated_by,
                "deprecated_at": now,
                "reason": reason,
            }
        )
        existing[memory_path] = self._json_bytes(memory)
        return (
            {"memory_id": memory_id, "memory_path": memory_path, "action": action},
            {memory_path},
            now,
            f"Deprecated memory `{memory_id}` in `{memory_path}`.",
        )

    def _merge_entries(
        self,
        existing: dict[str, bytes],
        target_id: str,
        source_id: str,
        merged_by: str,
        reason: str,
        statement: str | None,
        now: str,
    ) -> tuple[dict[str, str], set[str], str, str]:
        target_path, target_memory, target = self._find_entry(existing, target_id)
        source_path, source_memory, source = self._find_entry(existing, source_id)
        if target_path == source_path:
            source_memory = target_memory
            source = self._entry_by_id(target_memory, source_path, source_id)
        target_history = target.setdefault("maintenance_history", [])
        source_history = source.setdefault("maintenance_history", [])
        if not isinstance(target_history, list) or not isinstance(source_history, list):
            raise ValueError("maintenance_history must be a list")

        merged_from = target.setdefault("merged_from", [])
        if not isinstance(merged_from, list):
            raise ValueError("merged_from must be a list")
        merged_from.append(
            {
                "memory_id": source_id,
                "memory_path": source_path,
                "statement": self._statement(source),
                "merged_by": merged_by,
                "merged_at": now,
                "reason": reason,
            }
        )
        previous_statement = self._statement(target)
        if statement is not None:
            self._set_statement(target, statement)
        target["updated_by"] = merged_by
        target["updated_at"] = now
        target_history.append(
            {
                "action": "merged_target",
                "merged_by": merged_by,
                "merged_at": now,
                "reason": reason,
                "source_memory_id": source_id,
                "previous_statement": previous_statement,
            }
        )

        source["status"] = "deprecated"
        source["deprecated_by"] = merged_by
        source["deprecated_at"] = now
        source["deprecation_reason"] = f"Merged into {target_id}: {reason}"
        source_history.append(
            {
                "action": "merged_source",
                "merged_by": merged_by,
                "merged_at": now,
                "reason": reason,
                "target_memory_id": target_id,
            }
        )

        existing[target_path] = self._json_bytes(target_memory)
        if source_path != target_path:
            existing[source_path] = self._json_bytes(source_memory)
        return (
            {"memory_id": target_id, "memory_path": target_path, "action": "merged"},
            {target_path, source_path},
            now,
            f"Merged memory `{source_id}` into `{target_id}`.",
        )

    def _memory_documents(self, existing: dict[str, bytes]) -> list[tuple[str, dict[str, Any]]]:
        documents = []
        for path in sorted(existing):
            if path == "user/memory.json" or path == "shared/memory.json" or (path.startswith("projects/") and path.endswith("/memory.json")):
                documents.append((path, self._read_json(existing[path], path)))
        return documents

    def _find_entry(self, existing: dict[str, bytes], memory_id: str) -> tuple[str, dict[str, Any], dict[str, Any]]:
        for memory_path, memory in self._memory_documents(existing):
            for entry in self._entries(memory, memory_path):
                if entry.get("id") == memory_id:
                    return memory_path, memory, entry
        raise ValueError(f"memory not found: {memory_id}")

    def _entry_by_id(self, memory: dict[str, Any], memory_path: str, memory_id: str) -> dict[str, Any]:
        for entry in self._entries(memory, memory_path):
            if entry.get("id") == memory_id:
                return entry
        raise ValueError(f"memory not found: {memory_id}")

    def _entries(self, memory: dict[str, Any], memory_path: str) -> list[dict[str, Any]]:
        entries = memory.get("memories")
        if entries is None:
            memory["memories"] = []
            return memory["memories"]
        if not isinstance(entries, list):
            raise ValueError(f"{memory_path} field 'memories' must be a list")
        for entry in entries:
            if not isinstance(entry, dict):
                raise ValueError(f"{memory_path} memory entries must be JSON objects")
        return entries

    def _summary(self, entry: dict[str, Any], memory_path: str, index: int) -> dict[str, Any]:
        return {
            "id": entry.get("id"),
            "memory_path": memory_path,
            "index": index,
            "status": entry.get("status", "active"),
            "statement": self._statement(entry),
            "category": entry.get("category") or entry.get("type"),
            "project_id": entry.get("project_id"),
        }

    def _statement(self, entry: dict[str, Any]) -> str:
        statement = entry.get("statement")
        if isinstance(statement, str):
            return statement
        text = entry.get("text")
        if isinstance(text, str):
            return text
        return ""

    def _set_statement(self, entry: dict[str, Any], statement: str) -> None:
        if "statement" in entry:
            entry["statement"] = statement
        elif "text" in entry:
            entry["text"] = statement
        else:
            entry["statement"] = statement

    def _read_json(self, raw: bytes, path: str) -> dict[str, Any]:
        try:
            data = json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"{path} is invalid JSON: {exc}") from exc
        if not isinstance(data, dict):
            raise ValueError(f"{path} must contain a JSON object")
        return data

    def _json_bytes(self, data: dict[str, Any]) -> bytes:
        return json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
