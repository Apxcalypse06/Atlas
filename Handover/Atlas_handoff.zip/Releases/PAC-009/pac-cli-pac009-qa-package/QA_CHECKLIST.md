# PAC-009 QA Checklist

- [x] `pac memory review` lists memory entries.
- [x] `pac memory update` updates statements and records maintenance history.
- [x] `pac memory deprecate` marks entries deprecated without deleting them.
- [x] `pac memory merge` annotates target and deprecates source.
- [x] Deprecated entries are hidden by default and visible with `--include-deprecated`.
- [x] Capsule remains valid after maintenance operations.
- [x] Existing PAC command tests still pass.
- [x] Atlas `START_HERE.md` is regenerated and up to date.
- [x] Atlas validation passes.
