# PAC-007.2.5 QA Checklist

- [x] Canonical pipeline is declared in `MANIFEST.json`.
- [x] PAC-005 role is `Import Conversation`.
- [x] PAC-006 role is `Extract Candidate Knowledge`.
- [x] PAC-007.1 role is `Create Validation Artifact`.
- [x] PAC-007.2 role is `Select + Classify Knowledge`.
- [x] PAC-007.3 role is `Commit to Memory`.
- [x] PAC-008 role is `Generate Cognitive Views & Handover`.
- [x] Architecture uses the canonical order.
- [x] README uses the canonical order.
- [x] Generated START_HERE uses the canonical order.
- [x] Atlas validation passes.
