# ATLAS-GOV-008 Package Manifest

Archive:

```text
atlas-gov-008-pac-status-closure.zip
```

## Purpose

Archive the governance change that makes `DONE` the final status for completed PACs and promotes PAC-007.2, PAC-007.3, and PAC-008.

## Included files

- `Current/ATLAS-GOV-008/STATUS.md`
- `Current/PAC-007.2/STATUS.md`
- `Current/PAC-007.3/STATUS.md`
- `Current/PAC-008/STATUS.md`
- `GOVERNANCE/CHANGE_PROTOCOL.md`
- `README/README.md`
- `MANIFEST.json`
- `START_HERE.md`
- `tools/atlas_validate.py`
