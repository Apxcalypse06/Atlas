# ATLAS-GOV-010 QA Checklist

- [x] `tools/atlas_backup.py` excludes `BACKUPS/` case-insensitively.
- [x] `tools/atlas_handoff.py` exists.
- [x] `Handover/Atlas_handoff.zip` can be generated.
- [x] Generated handoff package is below 512 MB.
- [x] Generated handoff package excludes `BACKUPS/`.
- [x] `START_HERE.md` is regenerated from the manifest.
- [x] Atlas validation passes.
