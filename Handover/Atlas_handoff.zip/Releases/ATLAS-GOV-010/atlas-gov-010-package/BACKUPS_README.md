# Atlas Backups

This directory is reserved for full-project rollback snapshots.

This protocol is tracked by `ATLAS-GOV-003`.

## Purpose

Release archives preserve PAC deliverables.

Backup archives preserve the Atlas workspace state before structural changes.

## Required Practice

Before future structural PAC or PAC patch work, create a backup:

```bash
py tools/atlas_backup.py PAC-007.3
```

The backup tool writes a ZIP snapshot under:

```text
Backups/
```

## Scope

Backups are for rollback.

They are not release artifacts and should not replace PAC release archives or QA packages.

## Exclusions

The backup tool excludes:

- `.git`;
- `BACKUPS` / `Backups` case-insensitively;
- `.codex_tmp`;
- Python cache directories;
- generated handoff ZIP files;
- temporary packaging directories.

This prevents recursive backups and local cache noise.

## Transfer Packages

Backups are local rollback material and should not be sent to a new assistant.

To create a lightweight assistant transfer package, run:

```bash
py tools/atlas_handoff.py
```

Default output:

```text
Handover/Atlas_handoff.zip
```
