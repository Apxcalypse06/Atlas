# ATLAS-GOV-010 Package Manifest

Archive:

```text
atlas-gov-010-transfer-package-backup-exclusion.zip
```

## Purpose

Archive the governance and tooling change that separates local rollback backups from lightweight assistant handoff packages.

## Included files

- `Current/ATLAS-GOV-010/STATUS.md`
- `BACKUPS/README.md`
- `GOVERNANCE/CHANGE_PROTOCOL.md`
- `README/README.md`
- `MANIFEST.json`
- `START_HERE.md`
- `tools/atlas_backup.py`
- `tools/atlas_handoff.py`
- `tools/atlas_generate_start_here.py`
- `tools/atlas_validate.py`
