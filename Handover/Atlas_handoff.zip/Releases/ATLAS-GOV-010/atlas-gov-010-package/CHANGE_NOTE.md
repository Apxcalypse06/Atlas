# ATLAS-GOV-010 Change Note

## Summary

`ATLAS-GOV-010` fixes recursive backup growth and adds a lightweight assistant handoff package.

## Changes

- `tools/atlas_backup.py` excludes `BACKUPS/` case-insensitively.
- `tools/atlas_backup.py` excludes `.codex_tmp/`.
- `tools/atlas_handoff.py` creates `Handover/Atlas_handoff.zip`.
- The handoff package excludes local rollback backups and local caches.

## Boundary

This is a packaging and governance change only. It does not change PAC memory behavior.
